from spgmi_api_sdk.esgscores.constants.esg_scores_constants import EsgScoresConstants



class DataConfig:

    def get_criteria_name(self):
        return EsgScoresConstants.criteria_name

    def get_current_alignment_mapping(self):
        return EsgScoresConstants.current_alignment_mapping

    def get_identifier_conversion_mnemonic(self):
        return EsgScoresConstants.identifier_conversion_mnemonic

    def get_identifier_conversion_function(self):
        return EsgScoresConstants.identifier_conversion_function



