import traceback
from urllib.error import HTTPError

from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector

from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput
from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataRequest
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.kensho.constants.data_config import DataConfig
from spgmi_api_sdk.kensho.constants.error_messages import ErrorMessages
from spgmi_api_sdk.kensho.constants.property_constants import PropertyConstants
from spgmi_api_sdk.kensho.services.helper.data_transform import DataFormat
from spgmi_api_sdk.kensho.services.helper.request_validator import RequestValidator
import logging.config

from spgmi_api_sdk.kensho.services.kensho_services_interface import KenshoServicesInterface
from spgmi_api_sdk.kensho.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)

class SDKKenshoServices(KenshoServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.data_config = DataConfig()
        self.error_messages = ErrorMessages()
        self.property_constants = PropertyConstants()
        self.request_validator = RequestValidator()
        self.request_director = RequestDirector()
        self.data_format = DataFormat()

    def get_company_name_to_id(self, token, companies, identifier_type=None,proxy=None):
        kensho_properties = {"uid": "1",  "include_response_fields": ""}
        if identifier_type:
            kensho_properties["response_identifier_type"] = identifier_type
        kensho_function = self.data_config.get_company_name_to_id_function()
        kensho_mnemonics = self.data_config.get_company_name_to_id_mnemonics()
        ticker_function = self.data_config.get_ticker_id_function()
        ticker_mnemonics = self.data_config.get_ticker_id_mnemonics()
        error_messages = self.request_validator.validate_request(companies,identifier_type)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            sdk_data_request1 = self.__create_sdk_data_request(companies, kensho_function, kensho_properties, kensho_mnemonics)
            sdk_input_request1 = self.__create_sdk_data_input(token, proxy, sdk_data_request1)
            final_output1 = self.data_services._invoke_data_service(sdk_input_request1)
            df1 = self.data_format._convert_to_dataframe_pitv(final_output1)
            identifiers = df1["Company ID"].tolist()
            identifier_mapping = self.data_services._convert_all_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            sdk_data_request2 = self.__create_sdk_data_request(identifiers_converted, ticker_function, mnemonics=ticker_mnemonics)
            sdk_input_request2 = self.__create_sdk_data_input(token, proxy, sdk_data_request2)
            final_output2 = self.data_services._invoke_data_service(sdk_input_request2)
            df2 = self.data_format._convert_to_dataframe_pit(final_output2,identifier_mapping)
            merged_df = self.data_format._merge_response(df1, df2)
            return merged_df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input






