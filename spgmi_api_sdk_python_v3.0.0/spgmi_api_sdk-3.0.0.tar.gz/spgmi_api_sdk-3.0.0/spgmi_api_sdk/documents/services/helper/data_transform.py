import pandas as pd
import logging
from datetime import datetime, date, timedelta
from spgmi_api_sdk.documents.constants.error_messages import ErrorMessages

logger = logging.getLogger(__name__)

class DataFormat:
    def __init__(self):
        self.error_messages = ErrorMessages()

    def _format_response(self, combined_responses):
        formatted_response = {}

        filings = combined_responses.get('filings', {})
        transcripts = combined_responses.get('transcripts', {})

        filings_grouped = {}
        if filings.get('currentPageSize') is not None and filings.get('rows') is not None:
            for row in filings['rows']:
                company_id = row['row'][0]
                datetime_str = row['row'][2]
                document_text = row['row'][6]

                dt_obj = datetime.strptime(datetime_str, '%Y-%m-%d')
                date_str = dt_obj.strftime('%Y-%m-%d')

                if company_id not in filings_grouped:
                    filings_grouped[company_id] = []

                #if len(filings_grouped[company_id]) < 10:
                filings_grouped[company_id].append({
                    'flag': 'F',
                    'date': date_str,
                    'Documents and Transcripts': document_text
                })


        transcripts_grouped = {}
        if transcripts.get('currentPageSize') is not None and transcripts.get('rows') is not None:
            for row in transcripts['rows']:
                company_id = row['row'][0]
                datetime_str = row['row'][7]
                document_text = row['row'][11]

                dt_obj = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S.%f %z')
                date_str = dt_obj.strftime('%Y-%m-%d')

                if company_id not in transcripts_grouped:
                    transcripts_grouped[company_id] = []
                #if len(transcripts_grouped[company_id]) < 10:
                transcripts_grouped[company_id].append({
                    'flag': 'T',
                    'date': date_str,
                    'Documents and Transcripts': document_text
                })

        all_company_ids = set(filings_grouped.keys()).union(set(transcripts_grouped.keys()))
        for company_id in all_company_ids:
            combined_response = []
            dates = []
            has_filings = company_id in filings_grouped
            has_transcripts = company_id in transcripts_grouped
            if has_filings:
                combined_response.extend(filings_grouped[company_id])
                dates.extend([entry['date'] for entry in filings_grouped[company_id]])
            if has_transcripts:
                combined_response.extend(transcripts_grouped[company_id])
                dates.extend([entry['date'] for entry in transcripts_grouped[company_id]])
            if not has_filings and not has_transcripts:
                combined_response.append({
                    'flag': 'N/A',
                    'date': 'Data Unavailable',
                    'Documents and Transcripts': 'Data Unavailable'
                })
            sorted_dates = sorted(dates, reverse=True)
            new_response_list = []
            date_count = 0

            for date in sorted_dates:
                matched_dicts = []
                for i in range(len(combined_response)):
                    if combined_response[i]['date'] == date:
                        matched_dicts.append(combined_response[i])
                        combined_response.pop(i)
                        break
                new_response_list.extend(matched_dicts)
                date_count += len(matched_dicts)

                if date_count >= 10:
                    break

            formatted_response["IQ" + str(company_id)] = new_response_list
        return formatted_response




    def _to_dataframe(self, data,identifier_mapping,identifiers):
        rows = []
        if isinstance(data, dict):
            for identifier, documents in data.items():
                for document in documents:
                    rows.append({
                        "Identifier": identifier,
                        "Documents and Transcripts": document.get('Documents and Transcripts', ''),
                        "Date": document.get('date', '')
                    })

        df = pd.DataFrame(rows)
        if not df.empty:
            df['Identifier'] = df['Identifier'].replace({v: k for k, v in identifier_mapping.items()})
            all_identifiers = set(identifier_mapping.keys())
            present_identifiers = set(df['Identifier'].unique())
            missing_identifiers = all_identifiers - present_identifiers
        else:
            df = pd.DataFrame(columns=['Identifier', 'Documents and Transcripts', 'Date'])
            missing_identifiers = set(identifier_mapping.keys())

        for missing_identifier in missing_identifiers:
            mapped_value = identifier_mapping.get(missing_identifier, '')
            if mapped_value in data:
                for document in data[mapped_value]:
                    df = pd.concat([df, pd.DataFrame([{
                        'Identifier': missing_identifier,
                        'Documents and Transcripts': document.get('Documents and Transcripts', ''),
                        'Date': document.get('date', '')
                    }])], ignore_index=True)
            else:
                error_message = mapped_value.removeprefix("IQ")
                if error_message.isdigit():
                    error_message = "Data Unavailable"
                elif missing_identifier.lower().startswith("iq"):
                    error_message = "Not Applicable"
                error_row = {
                    'Identifier': missing_identifier,
                    'Documents and Transcripts': error_message,
                    'Date': error_message
                }
                df = pd.concat([df, pd.DataFrame([error_row])], ignore_index=True)

        # Sort the DataFrame by 'Identifier' and then by 'Date' in descending order
        df = df.sort_values(by=['Identifier', 'Date'], ascending=[True, False]).reset_index(drop=True)

        df = df[[ 'Identifier', 'Documents and Transcripts', 'Date']]
        df.index = range(1, len(df) + 1)

        ordered_rows = []
        for identifier in identifiers:
            rows = df[df['Identifier'] == identifier]
            ordered_rows.append(rows)

        new_df = pd.concat(ordered_rows, ignore_index=True) if ordered_rows else pd.DataFrame(
            columns=['Identifier', 'Documents and Transcripts', 'Date'])

        new_df.index = range(1, len(new_df) + 1)  # Reset index to start from 1
        return new_df

        # response_color = 'lightyellow'
        # identifier_color = 'lightblue'
        #
        # header_styles = [
        #     {'selector': 'th.col0',
        #      'props': [('background-color', identifier_color), ('text-align', 'center'),
        #                ('border', '1px solid black')]}
        # ]
        #
        # # Ensure all columns are included for styling
        # columns_order = [col for col in df.columns]
        #
        # # Add styles for all columns
        # for i, col in enumerate(columns_order, start=1):  # Start at 1 for index alignment
        #     header_styles.append({'selector': f'th.col{i}',
        #                           'props': [('background-color', response_color), ('text-align', 'center'),
        #                                     ('border', '1px solid black')]})
        #
        # df_styled = df.style.set_table_styles(
        #     header_styles + [
        #         {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
        #     ]
        # ).set_properties(**{'text-align': 'center'})

       # return df

