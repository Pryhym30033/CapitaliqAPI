
DEFAULT_PROPERTIES = {
    'sdk': {
        'bearer_url': 'https://api-ciq.marketintelligence.spglobal.com/gdsapi/rest/authenticate/api/v1',
        'token_endpoint': '/token',
        'refresh_token_endpoint': '/tokenRefresh'
    }
}