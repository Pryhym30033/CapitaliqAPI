class PropertyNotFoundError(Exception):
    pass


class InvalidMnemonicError(Exception):
    def __init__(self, message="The provided mnemonic(s) are not valid."):
        self.message = message
        super().__init__(self.message)




