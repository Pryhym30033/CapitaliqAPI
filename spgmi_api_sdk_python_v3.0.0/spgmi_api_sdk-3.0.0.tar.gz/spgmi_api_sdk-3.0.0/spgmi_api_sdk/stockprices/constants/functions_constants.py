class FunctionConstants:

    _stock_prices_function = "GDSHE"
