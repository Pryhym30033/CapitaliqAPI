from abc import ABC, abstractmethod
import pandas as pd


class CorporateDataServicesInterface(ABC):

    @abstractmethod
    def get_corporate_data(self, token, identifiers, proxy=None) -> pd.DataFrame:
        pass
