from spgmi_api_sdk.authentication.services import SDKAuthenticateServices
from spgmi_api_sdk.agencyratings.services import SDKAgencyRatingsServices
from spgmi_api_sdk.ciq.decorators.decorators import retry_on_unauthorized
from spgmi_api_sdk.estimates.services import SDKEstimatesServices
from spgmi_api_sdk.financials.services import SDKFinancialServices
from spgmi_api_sdk.getlatestactivity.services import SDKGetLatestActivityServices
from spgmi_api_sdk.marketdata.services import SDKMarketDataServices
from spgmi_api_sdk.kensho.services import SDKKenshoServices
from spgmi_api_sdk.esgscores.services import SDKEsgScoresServices
from spgmi_api_sdk.corporatedata.services import SDKCorporateDataServices
from spgmi_api_sdk.multiples.services import SDKMultiplesServices
from spgmi_api_sdk.riskgaugescore.services import SDKRiskGaugeScoreServices
from spgmi_api_sdk.stockprices.services import SDKStockPricesServices
from spgmi_api_sdk.transactions.services import SDKTransactionsServices

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SDKProxy:
    proxy_username: Optional[str] = field(default="")
    proxy_password: Optional[str] = field(default="")
    proxy_host: Optional[str] = field(default=None)
    proxy_port: Optional[int] = field(default=None)
    proxy_domain: Optional[str] = field(default="")

    def __str__(self):
        return (f"SDKProxy(proxy_username={self.proxy_username}, proxy_password={self.proxy_password}, "
                f"proxy_host={self.proxy_host}, proxy_port={self.proxy_port}, proxy_domain={self.proxy_domain})")


class SDKDataServices:
    def __init__(self, username, password, proxy: Optional[SDKProxy] = None):
        self.username = username
        self.password = password
        self.proxy = proxy if proxy else SDKProxy()
        self.auth_services = SDKAuthenticateServices()

        self._financial_services = None
        self._marketdata_services = None
        self._kensho_services = None
        self._esgscores_services = None
        self._corporate_services = None
        self._transactions_services = None
        self._riskscoregauge_services = None
        self._multiples_services = None
        self._estimates_services = None
        self._stockprices_services = None
        self._agencyratings_services = None
        self._latest_activity_services = None

    def _get_access_token(self):
        return self.auth_services.get_token(self.username, self.password, proxy=self.proxy).get("access_token")

    def get_token(self):
        return self.auth_services.get_token(self.username, self.password, proxy=self.proxy)

    def get_refresh_token(self, refresh_token):
        return self.auth_services.get_refresh_token(refresh_token=refresh_token, proxy=self.proxy)

    def _get_financial_services(self):
        if self._financial_services is None:
            self._financial_services = SDKFinancialServices()
        return self._financial_services

    def _get_marketdata_services(self):
        if self._marketdata_services is None:
            self._marketdata_services = SDKMarketDataServices()
        return self._marketdata_services

    def _get_corporate_services(self):
        if self._corporate_services is None:
            self._corporate_services = SDKCorporateDataServices()
        return self._corporate_services

    def _get_estimates_services(self):
        if self._estimates_services is None:
            self._estimates_services = SDKEstimatesServices()
        return self._estimates_services

    def _get_transactions_services(self):
        if self._transactions_services is None:
            self._transactions_services = SDKTransactionsServices()
        return self._transactions_services

    def _get_risk_gauge_score_services(self):
        if self._riskscoregauge_services is None:
            self._riskscoregauge_services = SDKRiskGaugeScoreServices()
        return self._riskscoregauge_services

    def _get_stockprices_services(self):
        if self._stockprices_services is None:
            self._stockprices_services = SDKStockPricesServices()
        return self._stockprices_services

    def _get_agencyratings_services(self):
        if self._agencyratings_services is None:
            self._agencyratings_services = SDKAgencyRatingsServices()
        return self._agencyratings_services

    def _get_latest_activity_services(self):
        if self._latest_activity_services is None:
            self._latest_activity_services = SDKGetLatestActivityServices()
        return self._latest_activity_services

    def _get_esg_scores_services(self):
        if self._esgscores_services is None:
            self._esgscores_services = SDKEsgScoresServices()
        return self._esgscores_services

    def _get_multiples_services(self):
        if self._multiples_services is None:
            self._multiples_services = SDKMultiplesServices()
        return self._multiples_services

    def _get_kensho_services(self):
        if self._kensho_services is None:
            self._kensho_services = SDKKenshoServices()
        return self._kensho_services

    # ---------------- Market Data Methods ----------------
    @retry_on_unauthorized
    def get_pricing_info_pit(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_pricing_info_pit(
            token=token if token is not None else self._get_access_token(),
            identifiers=identifiers,
            properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_pricing_info_time_series(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_pricing_info_time_series(
            token=token if token is not None else self._get_access_token(),
            identifiers=identifiers,
            properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_dividend_info_pit(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_dividend_info_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_dividend_info_time_series(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_dividend_info_time_series(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_market_info_pit(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_market_info_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_market_info_time_series(self, identifiers, properties={}, token=None):
        return self._get_marketdata_services().get_market_info_time_series(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_market_data(self, identifiers, token=None):
        return self._get_marketdata_services().get_market_data(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    # ---------------- Financial Data Methods ----------------
    @retry_on_unauthorized
    def get_income_statement_pit(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_income_statement_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_income_statement_historical(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_income_statement_historical(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_balance_sheet_pit(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_balance_sheet_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_balance_sheet_historical(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_balance_sheet_historical(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_cash_flow_pit(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_cash_flow_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_cash_flow_historical(self, identifiers, properties={}, token=None):
        return self._get_financial_services().get_cash_flow_historical(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_financials_pit(self, identifiers, mnemonics, properties={}, token=None):
        return self._get_financial_services().get_financials_pit(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, mnemonics=mnemonics,
            properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_financials_historical(self, identifiers, mnemonics, properties={}, token=None):
        return self._get_financial_services().get_financials_historical(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, mnemonics=mnemonics,
            properties=properties,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_financials(self, identifiers, period_type=None, token=None):
        return self._get_financial_services().get_financials(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, period_type=period_type,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_corporate_data(self, identifiers, token=None):
        return self._get_corporate_services().get_corporate_data(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_estimates(self, identifiers, token=None):
        return self._get_estimates_services().get_estimates(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_transactions(self, identifiers, token=None):
        return self._get_transactions_services().get_transactions(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_risk_gauge_score(self, identifiers, scoring_date=None, token=None):
        return self._get_risk_gauge_score_services().get_risk_gauge_score(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers,scoring_date=scoring_date, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_stock_price(self, identifiers, token=None):
        return self._get_stockprices_services().get_stock_price(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_agency_ratings(self, identifiers, token=None):
        return self._get_agencyratings_services().get_agency_ratings(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_latest_activity(self, identifiers, token=None):
        return self._get_latest_activity_services().get_latest_activity(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_esg_scores(self, identifiers, assessment_year=None, token=None):
        return self._get_esg_scores_services().get_esg_scores(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers,
            assessment_year=assessment_year,
            proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_multiples(self, identifiers, token=None):
        return self._get_multiples_services().get_multiples(
            token=token if token is not None else self._get_access_token(), identifiers=identifiers, proxy=self.proxy
        )

    @retry_on_unauthorized
    def get_company_name_to_id(self, companies, identifier_type=None, token=None):
        return self._get_kensho_services().get_company_name_to_id(
            token=token if token is not None else self._get_access_token(), companies=companies, identifier_type=identifier_type,
            proxy=self.proxy
        )
