class FunctionConstants:

    _keydev_id_function = "GDSHE"
    _keydev_function = "GDSP"
