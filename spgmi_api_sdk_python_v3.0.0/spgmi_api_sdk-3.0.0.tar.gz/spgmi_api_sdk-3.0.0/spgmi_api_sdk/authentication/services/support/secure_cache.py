import hashlib
import binascii
import os


class SecureCache:
    def __init__(self):
        self.salt_length = 16
        self.iterations = 100000

    def generate_cache_key(self, username, password, stored_salt=None):
        if stored_salt:
            encrypted_password = self.__encrypt_password_with_salt(password, stored_salt)
        else:
            encrypted_password = self.__encrypt_password(password)
        return f"{username}:{encrypted_password}"

    def __encrypt_password(self, password):
        salt = self.__get_random_salt()
        dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, self.iterations)
        hashed_password = binascii.hexlify(salt + dk).decode()
        return hashed_password

    def __encrypt_password_with_salt(self, password, salt):
        dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, self.iterations)
        hashed_password = binascii.hexlify(salt + dk).decode()
        return hashed_password

    def __get_random_salt(self):
        return os.urandom(self.salt_length)

    def extract_salt_from_cache_key(self, cache_key):
        try:
            _, encrypted_password = cache_key.split(':')
            salt = binascii.unhexlify(encrypted_password)[:self.salt_length]
            return salt
        except Exception as e:
            return None
