from abc import ABC, abstractmethod
import pandas as pd


class EstimatesServicesInterface(ABC):

    @abstractmethod
    def get_estimates (self, token, identifiers, proxy=None):
        pass
