import logging
from datetime import datetime, timedelta

from dateutil.relativedelta import relativedelta


logger = logging.getLogger(__name__)

class SDKUtils:
    @staticmethod
    def calculate_start_end_dates(months_back=3):
        """
        Calculate the start and end dates based on the number of months back.
        By default, it calculates the dates for the last 3 months.
        """
        end_date = datetime.today().date()
        start_date = end_date - relativedelta(months=months_back)
        end_date_str = end_date.strftime("%m/%d/%Y")
        start_date_str = start_date.strftime("%m/%d/%Y")
        return start_date_str, end_date_str

    @staticmethod
    def get_as_of_date():
        """
        Get the asOfDate in MM/DD/YYYY format.
        """
        as_of_date = datetime.now() - timedelta(days=2)
        return as_of_date.strftime("%m/%d/%Y")