class MnemonicConstants:
    _stock_prices_mnemonics = [
        "IQ_CLOSEPRICE",
        "IQ_OPENPRICE",
        "IQ_HIGHPRICE",
        "IQ_LOWPRICE",
        "IQ_VOLUME"
    ]

    _stock_prices_mnemonics_caption = {
        "IQ_CLOSEPRICE": "Close Price",
        "IQ_OPENPRICE": "Open Price",
        "IQ_HIGHPRICE": "High Price",
        "IQ_LOWPRICE": "Low price",
        "IQ_VOLUME": "Volume"
    }
