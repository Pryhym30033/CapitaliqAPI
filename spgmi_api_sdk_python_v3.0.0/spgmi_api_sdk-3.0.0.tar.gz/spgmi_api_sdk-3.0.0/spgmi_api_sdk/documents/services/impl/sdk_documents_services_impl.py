import concurrent.futures

from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
import traceback
from urllib.error import HTTPError
import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.documents.services.documents_services_interface import DocumentsServicesInterface
from spgmi_api_sdk.documents.services.helper.data_transform import DataFormat
from spgmi_api_sdk.documents.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.documents.util.logging_utils import LoggingUtils
import pandas as pd
from datetime import datetime, date, timedelta
LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)
class SDKDocumentsServices(DocumentsServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_director = RequestDirector()
        self.data_format = DataFormat()
        self.request_validator = RequestValidator()
        self._default_properties = DefaultProperties()


    def get_documents(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_all_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            identifiers_converted_wo_IQ = [identifier.upper().removeprefix("IQ") for identifier in identifiers_converted]

            valid_identifiers = [identifier for identifier in identifiers_converted_wo_IQ if
                                 identifier.isdigit()]
            if not valid_identifiers:
                return self.data_format._to_dataframe([], identifier_mapping,identifiers)

            final_output = self._process_api_request(valid_identifiers,token,proxy)
            df = self.data_format._to_dataframe(final_output,identifier_mapping,identifiers)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e



    def _process_api_request(self, identifiers,token,proxy=None):

        current_date = datetime.now()
        f_current_date = current_date.strftime('%Y-%m-%d')
        ninety_days_ago = current_date - timedelta(days=89)
        f_ninety_days_ago = ninety_days_ago.strftime('%Y-%m-%d')

        institution_ids = [int(identifier) for identifier in identifiers]

        filings_payload = {
            "properties": {
                "companyId": institution_ids,
                "minFilingDate": f_ninety_days_ago,
                "maxFilingDate": f_current_date
            }
        }

        transcripts_payload = {
            "properties": {
                "companyId": institution_ids,
                "minTranscriptCreationDate": f_ninety_days_ago,
                "maxTranscriptCreationDate": f_current_date,
                "documentFormatTypeId": [3]
            }
        }
        def send_request(payload, url):
            return RequestDirector._send_sdk_request(
                self.request_director, bearer_token=token, sdk_proxy=proxy, retry=True, batch=[payload], url=url
            )


        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {
                'filings': executor.submit(send_request, filings_payload,
                                           self._default_properties.FILINGS_ENDPOINT_URL),
                'transcripts': executor.submit(send_request, transcripts_payload,
                                               self._default_properties.TRANSCRIPTS_ENDPOINT_URL)
            }


            filings_response = futures['filings'].result()
            transcripts_response = futures['transcripts'].result()
        combined_responses = {
            'filings': filings_response[0],
            'transcripts': transcripts_response[0]
        }

        results = self.data_format._format_response(combined_responses)
        return results