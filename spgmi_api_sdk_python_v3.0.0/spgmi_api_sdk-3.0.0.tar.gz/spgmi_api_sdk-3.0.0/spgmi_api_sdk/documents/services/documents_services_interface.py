from abc import ABC, abstractmethod
import pandas as pd

class DocumentsServicesInterface(ABC):

    @abstractmethod
    def get_documents(self, token, identifiers, proxy=None) -> pd.DataFrame:
        pass