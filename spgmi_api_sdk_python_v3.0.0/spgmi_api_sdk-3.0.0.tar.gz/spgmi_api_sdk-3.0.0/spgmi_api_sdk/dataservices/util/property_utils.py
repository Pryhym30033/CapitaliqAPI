import configparser
import os
import logging
from spgmi_api_sdk.dataservices.config.properties import DEFAULT_PROPERTIES
from spgmi_api_sdk.dataservices.config.constant_properties import CONSTANT_PROPERTIES

if 'CUSTOM_PROPERTIES_PATH' not in os.environ:
    os.environ['CUSTOM_PROPERTIES_PATH'] = 'config/sdk_application.properties'
logger = logging.getLogger(__name__)
class PropertyUtils:
    config = None

    @staticmethod
    def _load_config():
        try:
            if PropertyUtils.config is None:
                config = configparser.ConfigParser()
                custom_config_file = os.getenv('CUSTOM_PROPERTIES_PATH')

                # Load custom properties if available
                if custom_config_file and os.path.exists(custom_config_file):
                    config.read(custom_config_file)
                    logger.info("Reading properties from custom properties file")
                else:
                    logger.info("Reading properties from default properties file")
                    # Load default properties
                    for section, properties in DEFAULT_PROPERTIES.items():
                        if not config.has_section(section):
                            config.add_section(section)
                        for key, value in properties.items():
                            config.set(section, key, value)

                #logger.info("Reading constant properties from constant_properties.py")
                # Load constant properties
                for section, properties in CONSTANT_PROPERTIES.items():
                    if not config.has_section(section):
                        config.add_section(section)
                    for key, value in properties.items():
                        config.set(section, key, value)

                PropertyUtils.config = config
        except FileNotFoundError as e:
            print(f"Configuration file not found: {e}")
        except configparser.DuplicateSectionError:
            pass

    @staticmethod
    def _get_property(section, key):
        PropertyUtils._load_config()
        return PropertyUtils.config.get(section, key, fallback=None)

    @staticmethod
    def _check_version(url, versions):
        return any(version in url.strip() for version in versions)
