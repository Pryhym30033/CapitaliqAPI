from abc import ABC, abstractmethod
import pandas as pd

class EventsServicesInterface(ABC):

    @abstractmethod
    def get_events(self, token, identifiers, proxy=None) -> pd.DataFrame:
        pass