from abc import ABC, abstractmethod
import pandas as pd

class AgencyRatingsServicesInterface(ABC):

    @abstractmethod
    def get_agency_ratings(self, token, identifiers,  proxy=None) -> pd.DataFrame:
        pass