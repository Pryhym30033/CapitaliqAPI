class PropertyConstants:
    _IDENTIFIERS_SIZE = 10
    _MNEMONICS_SIZE = 15
    _SDK = "sdk"

    @property
    def identifiers_size(self):
        return self._IDENTIFIERS_SIZE

    @property
    def mnemonics_size(self):
        return self._MNEMONICS_SIZE

    @property
    def sdk(self):
        return self._SDK
