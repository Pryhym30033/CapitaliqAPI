import os
import logging
import logging.config

if 'LOGGING_CUSTOM_CONFIG_PATH' not in os.environ:
    os.environ['LOGGING_CUSTOM_CONFIG_PATH'] = 'config/logging.ini'

class LoggingUtils:
    @staticmethod
    def load_logging_config():
        custom_config_file = os.getenv('LOGGING_CUSTOM_CONFIG_PATH')

        logs_directory = 'logs'
        if not os.path.exists(logs_directory):
            os.makedirs(logs_directory)

        if custom_config_file and os.path.exists(custom_config_file):
            logging.config.fileConfig(custom_config_file, disable_existing_loggers=False)
            logger = logging.getLogger(__name__)
            logger.info("Reading log properties from custom properties file: %s", custom_config_file)






