CONSTANT_PROPERTIES = {
    'sdk': {
        'batch_size': '500',
        'max_threads': '10',
        'library_version': 'ciqapi_python_sdk_3.0.0'
    }
}