import traceback

import pandas as pd

import logging

logger = logging.getLogger(__name__)
class DataFormat:
    @staticmethod
    def getmultiples_response_to_dataframe(response, identifier_mapping):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            # reversed_mapping = {v: k for k, v in identifier_mapping.items()}

            # user_identifiers = list(dict.fromkeys(reversed_mapping.get(identifier, identifier)
            #                                       for item in response.values() for identifier in item.keys()))

            user_identifiers = list(identifier_mapping.keys())

            data = {'Identifier': user_identifiers}

            for mnemonic, item in response.items():
                data[f"{mnemonic}"] = [
                    next((value[0] for value in item.get(identifier_mapping.get(identifier, identifier), [])), None)
                    for identifier in user_identifiers
                ]

            df = pd.DataFrame(data)
            df.index = df.index + 1
            desired_order = [
                ("IQ_PE_EXCL", "P/LTM EPS (x)"),
                ("IQ_PE_EXCL_FWD_CIQ", "P/NTM EPS (x)"),
                ("IQ_PBV", "Price/Book (x)"),
                ("IQ_PTBV", "Price/Tang Book (x)"),
                ("IQ_TEV_TOTAL_REV", "TEV/LTM Total Revenue (x)"),
                ("IQ_TEV_EBITDA", "TEV/LTM EBITDA (x)"),
                ("IQ_TOTAL_DEBT_EBITDA", "Total Debt/EBITDA (x)")
            ]
            for mnemonic, caption in desired_order:
                if mnemonic in df.columns and not df[mnemonic].isnull().all():
                    df.rename(columns={mnemonic: f"{mnemonic} ({caption})"}, inplace=True)
            '''identifier_color = 'lightblue'
            mnemonic_color = 'lightyellow'

            header_styles = [
                {'selector': f'th.col0', 'props': [('background-color', identifier_color), ('text-align', 'center'),
                                                   ('border', '1px solid black')]},
            ]

            for i in range(1, len(df.columns)):
                header_styles.append({'selector': f'th.col{i}', 'props': [('background-color', mnemonic_color),
                                                                          ('text-align', 'center'),
                                                                          ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                    {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e