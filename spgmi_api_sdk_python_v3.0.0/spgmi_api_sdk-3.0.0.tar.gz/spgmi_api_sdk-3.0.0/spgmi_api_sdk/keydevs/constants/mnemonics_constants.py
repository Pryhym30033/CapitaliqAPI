class MnemonicConstants:

    _keydev_mnemonics = [
        "IQ_KEY_DEV_TYPE",
        "IQ_KEY_DEV_DATE",
        "IQ_KEY_DEV_SITUATION"
    ]
    _keydev_mnemonics_captions = {
            "IQ_KEY_DEV_TYPE": "Type",
            "IQ_KEY_DEV_DATE": "Date",
            "IQ_KEY_DEV_SITUATION": "Description",
            "IQ_KEY_DEV_ID":"Key Dev ID"
    }

    _keydev_id_mnemonics = [
        "IQ_KEY_DEV_ID"
    ]


