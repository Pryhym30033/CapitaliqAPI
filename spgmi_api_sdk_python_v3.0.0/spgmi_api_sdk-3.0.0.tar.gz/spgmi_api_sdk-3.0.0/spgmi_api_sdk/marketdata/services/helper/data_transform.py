import pandas as pd
import traceback

import logging

logger = logging.getLogger(__name__)
class DataFormat:
    @staticmethod
    def convert_to_dataframe_gdst(data, properties={}):
        as_of_date_key = next((k for k in properties if k.lower() == 'asofdate'), None)
        if as_of_date_key:
            del properties[as_of_date_key]
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()
        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []
            for sub_key, main_key_data in flattened_data.items():

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Identifier': sub_key}
                    date = ''
                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if i < len(values):
                            row[main_key] = values[i][0]

                            if len(values[i]) > 1 and values[i][1]:
                                date = values[i][1]

                        else:
                            row[main_key] = ''

                    row['asOfDate'] = date
                    for prop_key, prop_value in properties.items():
                        row[prop_key] = prop_value
                    rows.append(row)

            df = pd.DataFrame(rows)

            property_columns = list(properties.keys())
            response_columns = [col for col in df.columns if col not in ['Identifier', 'asOfDate'] + property_columns]

            columns_order = ['Identifier', 'asOfDate'] + response_columns + property_columns
            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            '''response_color = 'lightyellow'
            property_color = 'lightblue'

            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black'),
                           ('text-transform', 'uppercase')]},
                {'selector': 'th.col1',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black'),
                           ('text-transform', 'uppercase')]}
            ]

            # Add styles for response columns
            for i, col in enumerate(response_columns, start=2):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            # Add styles for property columns
            for i, col in enumerate(property_columns, start=2 + len(response_columns)):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', property_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]}
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df
        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e



    @staticmethod
    def convert_to_dataframe_pit(data, properties={}):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()

        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []
            for sub_key, main_key_data in flattened_data.items():

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Identifier': sub_key}

                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if i < len(values):
                            row[main_key] = values[i][0]

                        else:
                            row[main_key] = ''

                    for prop_key, prop_value in properties.items():
                        row[prop_key] = prop_value
                    rows.append(row)

            df = pd.DataFrame(rows)

            property_columns = list(properties.keys())
            has_as_of_date = 'asOfDate' in properties

            if has_as_of_date:
                property_columns.remove('asOfDate')
                columns_order = ['Identifier', 'asOfDate'] + [col for col in df.columns if
                                                              col not in property_columns + ['Identifier',
                                                                                             'asOfDate']] + property_columns
            else:
                columns_order = ['Identifier'] + [col for col in df.columns if
                                                  col not in property_columns + ['Identifier']] + property_columns

            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            '''response_color = 'lightyellow'
            property_color = 'lightblue'

            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black'),
                           ('text-transform', 'uppercase')]}
            ]

            if has_as_of_date:
                header_styles.append({'selector': 'th.col1',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})
                response_start_index = 2
            else:
                response_start_index = 1

            # Add styles for response columns
            for i, col in enumerate(columns_order[response_start_index:response_start_index + len(data)],
                                    start=response_start_index):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            # Add styles for property columns
            for i, col in enumerate(columns_order[response_start_index + len(data):],
                                    start=response_start_index + len(data)):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', property_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]}
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df
        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e

    @staticmethod
    def convert_to_dataframe_gdshe(data, properties={}):
        normalized_properties = {k.lower(): v for k, v in properties.items()}
        meta_data_tag = normalized_properties.get('metadatatag', 'asOfDate')
        if meta_data_tag.lower() == 'asofdate':
            as_of_date_key = next((k for k in properties if k.lower() == 'asofdate'), None)
            if as_of_date_key:
                del properties[as_of_date_key]

        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()

        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []
            for sub_key, main_key_data in flattened_data.items():

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Identifier': sub_key}
                    date = ''
                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if i < len(values):
                            row[main_key] = values[i][0]

                            if len(values[i]) > 1 and values[i][1]:
                                date = values[i][1]

                        else:
                            row[main_key] = ''

                    row[meta_data_tag] = date
                    for prop_key, prop_value in properties.items():
                        row[prop_key] = prop_value
                    rows.append(row)

            df = pd.DataFrame(rows)

            property_columns = list(properties.keys())
            response_columns = [col for col in df.columns if
                                col not in ['Identifier', meta_data_tag] + property_columns]

            columns_order = ['Identifier'] + [meta_data_tag] + response_columns + property_columns
            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            '''response_color = 'lightyellow'
            property_color = 'lightblue'

            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black'),
                           ('text-transform', 'uppercase')]},
                {'selector': 'th.col1',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black'),
                           ('text-transform', 'uppercase')]}
            ]

            for i, col in enumerate(response_columns, start=2):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            for i, col in enumerate(property_columns, start=2 + len(response_columns)):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', property_color), ('text-align', 'center'),
                                                ('border', '1px solid black'), ('text-transform', 'uppercase')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]}
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df
        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e

    @staticmethod
    def getmarketdata_response_to_dataframe(response, identifier_mapping):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            user_identifiers = list(identifier_mapping.keys())


            data = {'Identifier': user_identifiers}
            mnemonic_caption_map = {
                "IQ_CLOSEPRICE": "Last (Delayed)",
                "IQ_VWAP": "VWAP (Delayed)",
                "IQ_OPENPRICE": "Open",
                "IQ_CLOSEPRICE_PREV": "Previous Close",
                "IQ_HIGHPRICE": "Day High",
                "IQ_LOWPRICE": "Day Low",
                "IQ_YEARHIGH": "52 wk High",
                "IQ_YEARLOW": "52 wk Low",
                "IQ_BETA_5YR": "Beta 5Y",
                "IQ_MARKETCAP": "Market Cap.($M)",
                "IQ_TEV": "Total Enterprise Value ($M)",
                "IQ_VOLUME": "Volume",
                "IQ_VOLUME_AVG_3M": "Volume (Avg 3M Daily Volume)",
                "IQ_SHARESOUTSTANDING": "Shares Out.",
                "IQ_FLOAT_PERCENT": "Float (%)",
                "IQ_DIVIDEND_YIELD": "Div. Yield (%)"
            }

            extracted_data = {mnemonic: [] for mnemonic in mnemonic_caption_map.keys()}

            for mnemonic, item in response.items():
                for identifier in user_identifiers:
                    ciq_identifier = identifier_mapping.get(identifier, identifier)
                    values = item.get(ciq_identifier, [])

                    if mnemonic == "IQ_VOLUME":
                        volume_values = [v[0] if isinstance(v, list) and v else None for v in values]
                        numeric_values = [float(v) for v in volume_values if isinstance(v, (int, float)) or (
                                    isinstance(v, str) and v.replace('.', '', 1).isdigit())]
                        latest_volume = volume_values[0] if volume_values else None
                        if numeric_values:
                            avg_3m_volume = DataFormat.calculate_3_month_avg(numeric_values[1:])
                            if avg_3m_volume is None:
                                avg_3m_volume = volume_values[1] if len(volume_values)>0 else volume_values[0]
                        else:
                            avg_3m_volume = volume_values[0] if volume_values else None

                        extracted_data["IQ_VOLUME"].append(latest_volume)
                        extracted_data["IQ_VOLUME_AVG_3M"].append(avg_3m_volume)

                    elif mnemonic == "IQ_CLOSEPRICE":
                        close_prices = [v[0] if isinstance(v, list) and v else None for v in values]

                        last_delayed = close_prices[0] if len(close_prices) > 0 else None
                        if close_prices:
                            previous_close = close_prices[1] if len(close_prices) > 1 else close_prices[0]
                        else:
                            previous_close = None

                        extracted_data["IQ_CLOSEPRICE"].append(last_delayed)
                        extracted_data["IQ_CLOSEPRICE_PREV"].append(previous_close)
                    else:
                        processed_values = []
                        for v in values:
                            if isinstance(v, str):
                                processed_values.append(v)
                            elif isinstance(v, list) and v:
                                processed_values.append(v[0])
                            else:
                                processed_values.append(None)

                        extracted_data[mnemonic].append(processed_values[-1] if processed_values else None)

            data["IQ_CLOSEPRICE (Last (Delayed))"] = extracted_data.get("IQ_CLOSEPRICE", [None] * len(user_identifiers))
            data["IQ_VWAP (VWAP (Delayed))"] = extracted_data.get("IQ_VWAP", [None] * len(user_identifiers))
            data["IQ_OPENPRICE (Open)"] = extracted_data.get("IQ_OPENPRICE", [None] * len(user_identifiers))
            data["IQ_CLOSEPRICE (Previous Close)"] = extracted_data.get("IQ_CLOSEPRICE_PREV",
                                                                        [None] * len(user_identifiers))
            data["IQ_HIGHPRICE (Day High)"] = extracted_data.get("IQ_HIGHPRICE", [None] * len(user_identifiers))
            data["IQ_LOWPRICE (Day Low)"] = extracted_data.get("IQ_LOWPRICE", [None] * len(user_identifiers))
            data["IQ_YEARHIGH (52 wk High)"] = extracted_data.get("IQ_YEARHIGH", [None] * len(user_identifiers))
            data["IQ_YEARLOW (52 wk Low)"] = extracted_data.get("IQ_YEARLOW", [None] * len(user_identifiers))
            data["IQ_BETA_5YR (Beta 5Y)"] = extracted_data.get("IQ_BETA_5YR", [None] * len(user_identifiers))
            data["IQ_MARKETCAP (Market Cap.($M))"] = extracted_data.get("IQ_MARKETCAP", [None] * len(user_identifiers))
            data["IQ_TEV (Total Enterprise Value ($M))"] = extracted_data.get("IQ_TEV", [None] * len(user_identifiers))
            data["IQ_VOLUME (Volume)"] = extracted_data.get("IQ_VOLUME", [None] * len(user_identifiers))
            data["IQ_VOLUME (Avg 3M Daily Volume)"] = extracted_data.get("IQ_VOLUME_AVG_3M",
                                                                                  [None] * len(user_identifiers))
            data["IQ_SHARESOUTSTANDING (Shares Out.)"] = extracted_data.get("IQ_SHARESOUTSTANDING",
                                                                            [None] * len(user_identifiers))
            data["IQ_FLOAT_PERCENT (Float (%))"] = extracted_data.get("IQ_FLOAT_PERCENT",
                                                                      [None] * len(user_identifiers))
            data["IQ_DIVIDEND_YIELD (Div. Yield (%))"] = extracted_data.get("IQ_DIVIDEND_YIELD",
                                                                            [None] * len(user_identifiers))

            df = pd.DataFrame(data)
            df.index = df.index + 1
            '''identifier_color = 'lightblue'
            mnemonic_color = 'lightyellow'

            header_styles = [
                {'selector': f'th.col0', 'props': [('background-color', identifier_color), ('text-align', 'center'),
                                                   ('border', '1px solid black')]},
            ]

            for i in range(1, len(df.columns)):
                header_styles.append({'selector': f'th.col{i}', 'props': [('background-color', mnemonic_color),
                                                                          ('text-align', 'center'),
                                                                          ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                    {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e

    @staticmethod
    def calculate_3_month_avg(values):
        try:
            if not values:
                return None
            return sum(values) / len(values)
        except Exception as e:
            logger.error(f"Error calculating 3-month average: {e}")
            traceback.print_exc()
            raise e








