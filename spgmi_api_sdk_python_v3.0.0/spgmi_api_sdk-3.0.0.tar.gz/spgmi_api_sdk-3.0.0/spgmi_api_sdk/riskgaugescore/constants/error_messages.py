class ErrorMessages:
    _IDENTIFIERS_FORMAT_ERROR = "The 'identifiers' parameter must be a list with at least one identifier."
    _IDENTIFIERS_SIZE = 10
    _IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR = f"The 'identifiers' list should not contain more than {_IDENTIFIERS_SIZE} items."
    _SCORING_DATE_DATATYPE_ERROR = "scoring_date must be a string in MM/DD/YYYY format."
    _SCORING_DATE_FORMAT_ERROR = "scoring_date must be a valid date in MM/DD/YYYY format."

    @property
    def identifiers_format_error(self):
        return self._IDENTIFIERS_FORMAT_ERROR

    @property
    def identifiers_size(self):
        return self._IDENTIFIERS_SIZE

    @property
    def identifiers_list_size_exceeded_error(self):
        return self._IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR

    @property
    def scoring_date_datatype_error(self):
        return self._SCORING_DATE_DATATYPE_ERROR

    @property
    def scoring_date_format_error(self):
        return self._SCORING_DATE_FORMAT_ERROR



