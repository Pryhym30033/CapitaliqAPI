class CachingConstants:
    EXPIRES_AT = "expires_at"

