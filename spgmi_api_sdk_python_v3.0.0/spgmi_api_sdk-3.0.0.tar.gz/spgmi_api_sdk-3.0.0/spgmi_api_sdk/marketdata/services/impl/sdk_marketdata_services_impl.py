import traceback

from requests import HTTPError

from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput
from spgmi_api_sdk.dataservices.model.sdk_data_request import SDKDataRequest
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.marketdata.constants.error_messages import ErrorMessages
from spgmi_api_sdk.marketdata.constants.property_constants import PropertyConstants
from spgmi_api_sdk.marketdata.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.marketdata.util.logging_utils import LoggingUtils
from spgmi_api_sdk.marketdata.constants.data_config import DataConfig
from spgmi_api_sdk.marketdata.services.helper.data_transform import DataFormat
from spgmi_api_sdk.marketdata.services.sdk_marketdata_interface import MarketDataServicesInterface
from spgmi_api_sdk.marketdata.services.helper.marketdata_request_utils import MarketDataRequestUtils

import logging.config

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)



class SDKMarketDataServices(MarketDataServicesInterface):

    def __init__(self):
        self.data_services = SDKDataServices()
        self.data_config = DataConfig()
        self.error_messages = ErrorMessages()
        self.property_constants = PropertyConstants()
        self.request_validator = RequestValidator()
        self.market_data_utils = MarketDataRequestUtils()

    def get_pricing_info_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_pricing_info_pit_function()
        mnemonics = self.data_config.get_pricing_info_pit_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_pricing_info_time_series(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_pricing_info_time_series_function()
        mnemonics = self.data_config.get_pricing_info_time_series_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdst(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_dividend_info_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_dividend_info_pit_function()
        mnemonics = self.data_config.get_dividend_info_pit_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_dividend_info_time_series(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_dividend_info_time_series_function()
        mnemonics = self.data_config.get_dividend_info_time_series_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_market_info_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_market_info_pit_function()
        mnemonics = self.data_config.get_market_info_pit_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_market_info_time_series(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_market_info_time_series_function()
        mnemonics = self.data_config.get_market_info_time_series_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdst(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e
    def get_market_data(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_generic_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            payloads = self.market_data_utils.generate_market_data_payloads(identifiers_converted)
            response = self.data_services._invoke_data_service_with_payload(token,
                                                                             proxy,
                                                                             payloads
                                                                             )
            df = DataFormat.getmarketdata_response_to_dataframe(response,identifier_mapping)
            return df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input
