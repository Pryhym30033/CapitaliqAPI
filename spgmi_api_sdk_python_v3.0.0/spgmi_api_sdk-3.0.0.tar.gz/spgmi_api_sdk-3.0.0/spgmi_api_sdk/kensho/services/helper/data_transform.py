import traceback

import pandas as pd
import logging

from spgmi_api_sdk.kensho.constants.error_messages import ErrorMessages

logger = logging.getLogger(__name__)
class DataFormat:

    def __init__(self):
        self.error_messages = ErrorMessages()

    import pandas as pd
    import traceback
    import logging

    logger = logging.getLogger(__name__)

    def _convert_to_dataframe_pitv(self, data):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        flattened_data = {}
        all_subkeys = set()
        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]
            rows = []
            for sub_key, main_key_data in flattened_data.items():

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Company': sub_key}

                    for main_key in data.keys():
                        values = main_key_data[main_key]

                        if i < len(values):
                            if len(values[i]) > 2:
                                values[i][2] = values[i][2].replace("MI", "SNL")
                                row['Company ID'] = values[i][2]
                            elif len(values[i]) == 1:
                                row['Company ID'] = values[i][0]
                            else:
                                row['Company ID'] = 'Data Unavailable'

                            if len(values[i]) > 3:
                                row['Company Name'] = values[i][3]
                            elif len(values[i]) == 1:
                                row['Company Name'] = values[i][0]
                            else:
                                row['Company Name'] = 'Data Unavailable'
                        else:
                            row['Company ID'] = 'Data Unavailable'
                            row['Company Name'] = 'Data Unavailable'


                    rows.append(row)

            df = pd.DataFrame(rows)

            columns_order =  [col for col in df.columns ]

            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            #raise e
            traceback.print_exc()
            #return None
            raise e

    def _convert_to_dataframe_pit(self,data, identifier_dict={}):
        reversed_identifier_dict = {value: key for key, value in identifier_dict.items()}

        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()
        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []
            for sub_key, main_key_data in flattened_data.items():
                sub_key_snl = reversed_identifier_dict.get(sub_key)

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Company ID': sub_key_snl}

                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if i < len(values):
                            row['Ticker'] = values[i][0]

                        else:
                            row['Ticker'] = ''


                    rows.append(row)

            df = pd.DataFrame(rows)



            columns_order = [col for col in df.columns]
            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            # raise e
            traceback.print_exc()
            # return None
            raise e

    def _merge_response(self,data1,data2):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            # Merge the DataFrames
            merged_df = pd.merge(data1, data2, on="Company ID", how="left")
            merged_df["Company ID"] = merged_df["Company ID"].apply(
                lambda company_id: company_id.replace("SNL", "MI", 1) if company_id.startswith("SNL") else company_id
            )

            columns_order = ['Company'] + ['Company ID'] + ['Company Name'] + ['Ticker']

            df = merged_df[columns_order]
            df.index = range(1, len(df) + 1)
            '''response_color = 'lightyellow'
            identifier_color = 'lightblue'


            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', identifier_color), ('text-align', 'center'),
                           ('border', '1px solid black')]}
            ]

            # Add styles for all columns
            for i, col in enumerate(columns_order, start=1):  # Start at 1 for index alignment
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            df = df.drop_duplicates().reset_index(drop=True)
            df.index = range(1, len(df) + 1)
            return df



        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            # raise e
            traceback.print_exc()
            # return None
            raise e





