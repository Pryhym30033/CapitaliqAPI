from abc import ABC, abstractmethod
import pandas as pd

class KeyDevsServicesInterface(ABC):

    @abstractmethod
    def get_key_devs(self, token, identifiers, proxy=None) -> pd.DataFrame:
        pass