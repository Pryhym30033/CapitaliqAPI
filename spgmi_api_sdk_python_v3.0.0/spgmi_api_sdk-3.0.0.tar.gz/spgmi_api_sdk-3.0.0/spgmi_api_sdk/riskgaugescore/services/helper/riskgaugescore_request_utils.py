import logging

from spgmi_api_sdk.riskgaugescore.constants.functions_constants import Functions
from spgmi_api_sdk.riskgaugescore.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)

class RiskGaugeScoreRequestUtils:
    @staticmethod
    def generate_riskgaugescore_request_payload(identifiers,scoring_date,function=Functions.GDSP):
        mnemonics_payload = []
        desired_order = [
            ("IQ_RG_STANDALONE_CREDIT_SCORE", "RiskGauge - Standalone Score"),
            ("IQ_RG_STANDALONE_ONE_TO_HUNDRED", "RiskGauge - Standalone Score 1 - 100"),
            ("IQ_RG_SOV_CREDIT_SCORE", "RiskGauge - Sovereign Capped Score"),
            ("IQ_RG_SOV_ONE_TO_HUNDRED", "RiskGauge - Sovereign Capped Score 1 - 100"),
            ("IQ_RG_PG_CREDIT_SCORE", "RiskGauge - Sovereign Capped Parental & Govt. Support Score"),
            ("IQ_RG_PG_ONE_TO_HUNDRED","RiskGauge - Sovereign Capped Parental & Govt. Support Score 1 - 100")
        ]

        for mnemonic, caption in desired_order:
            for identifier in identifiers:
                properties = {"modelId": "RG"}
                if scoring_date:
                    properties["scoringdate"] = scoring_date
                payload = {
                    "identifier":identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                mnemonics_payload.append(payload)

        return mnemonics_payload

