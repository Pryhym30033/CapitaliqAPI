import pandas as pd
import traceback
from urllib.error import HTTPError


from spgmi_api_sdk.agencyratings.services.helper.data_transform import DataFormat
from spgmi_api_sdk.agencyratings.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.agencyratings.util.logging_utils import LoggingUtils
from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.agencyratings.services.agency_ratings_interface import AgencyRatingsServicesInterface
import logging.config
LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)

class SDKAgencyRatingsServices(AgencyRatingsServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_director = RequestDirector()
        self._default_properties = DefaultProperties()
        self.data_format = DataFormat()
        self.request_validator = RequestValidator()



    def get_agency_ratings(self, token, identifiers, proxy=None) :
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")

        try:
            identifier_mapping = self.data_services._convert_all_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            identifiers_converted_wo_IQ = [identifier.upper().removeprefix("IQ") for identifier in identifiers_converted]

            valid_identifiers = [identifier for identifier in identifiers_converted_wo_IQ if
                                           identifier.isdigit()]

            if not valid_identifiers:
                return self.data_format._convert_to_dataframe([], identifier_mapping,identifiers)


            input_request = self.__create_sdk_data_request(valid_identifiers)
            response = RequestDirector._send_sdk_request(self.request_director, bearer_token=token,
                                                              sdk_proxy=proxy, retry=True,
                                                              batch=input_request,
                                                              url=self._default_properties.AGENCY_RATINGS_URL)


            if response:
                results = self.data_format._format_response(response,identifier_mapping)
                df =  self.data_format._convert_to_dataframe(results,identifier_mapping,identifiers)
                return df
            else:
                return pd.DataFrame()
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e








    def __create_sdk_data_request(self, identifiers):
        #institution_ids = [identifier[2:] for identifier in identifiers]
        payload = {
            "identifierType": "CIQCOMPANYID",
            "identifierValues": identifiers,
            "creditRatingAgency": "S&P + Moody's + FITCH",
            "asOfDate": "",
            "startDate": "",
            "endDate": "",
            "generateDriveInputFile": ""
        }
        return [payload]




