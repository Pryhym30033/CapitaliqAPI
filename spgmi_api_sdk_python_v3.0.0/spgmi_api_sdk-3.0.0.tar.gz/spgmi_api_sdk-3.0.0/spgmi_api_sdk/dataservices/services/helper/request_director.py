import json
import socket
import traceback

import concurrent.futures

import requests
import urllib3
from requests import HTTPError

from spgmi_api_sdk.authentication.services.impl.sdk_authenticate_service_impl import SDKAuthenticateServices

from spgmi_api_sdk.dataservices.constants.exception_messages import ExceptionMessages
from spgmi_api_sdk.dataservices.exceptions.sdk_data_services_exceptions import APIRequestException, DNSResolutionError, \
    DataRequestError
from spgmi_api_sdk.dataservices.services.support.rest_gateway_support import RestGatewaySupport
from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.util.property_utils import PropertyUtils
from spgmi_api_sdk.dataservices.constants.sdk_constants import SDKConstants
from copy import deepcopy
import json
import time
import traceback
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.exceptions import HTTPError

logger = logging.getLogger(__name__)
class RequestDirector:
    def __init__(self):
        self._default_properties = DefaultProperties()
        self._auth_services = SDKAuthenticateServices()

    def _execute_in_batch(self, bearer_token, sdk_proxy, function=None, identifiers=None, mnemonics=None,
                          properties={}):
        if identifiers != None:
            results = []
            requests_to_send = []
            uid = 1
            for identifier in identifiers:
                for mnemonic in mnemonics:
                    if "uid" in properties:
                        properties["uid"] = str(uid)
                        uid += 1
                    request_properties = deepcopy(properties)
                    requests_to_send.append({
                        "function": function,
                        "identifier": str(identifier),
                        "mnemonic": mnemonic,
                        "properties": request_properties,
                    })

            resultss = self._send_sdk_request(bearer_token, sdk_proxy, True, requests_to_send)
            return resultss
        else:
            return self._send_sdk_request(bearer_token, sdk_proxy)

    def _send_sdk_request(self, bearer_token, sdk_proxy, retry=False, batch=None, results=None, url=""):
        try:

            if url == "":
                url = self._default_properties.REST_BY_JSON_URL
            supported_versions = SDKConstants.SUPPORTED_VERSIONS

            if not PropertyUtils._check_version(self._default_properties.REST_BY_JSON_URL, supported_versions):
                error_message = "Only v3 version is supported"
                traceback.print_exc()
                raise ValueError(error_message)

            if batch is None or len(batch) == 0:
                return {"GDSSDKResponse": []}

            def send_batch_request(batch_chunk):
                """Function to send a single batch request."""
                batch_payload = {"inputRequests": batch_chunk} if url in [
                    self._default_properties.REST_BY_JSON_URL
                ] else batch_chunk[0]


                headers = {
                    "Content-Type": "application/json",
                    "client_version": str(self._default_properties.SDK_CLIENT_VERSION),
                    "client_ip": str(self.__get_client_ip()),
                    "Authorization": f"Bearer {bearer_token}"
                }

                session = RestGatewaySupport._create_rest_template(sdk_proxy)
                response = None
                try:
                    response = session.post(url, headers=headers, data=json.dumps(batch_payload))
                    if response.status_code == 200:
                        return response.json()
                    else:
                        response.raise_for_status()


                except HTTPError as http_err:
                    raise APIRequestException(response.status_code, response.text)
                except (requests.exceptions.ConnectionError, urllib3.exceptions.MaxRetryError) as e:
                    error_msg = f"Connection error occurred: {str(e)}"
                    #logger.error(error_msg)
                    raise ConnectionError(f"Failed to establish connection to host '{url}': {str(e)}")
                except urllib3.exceptions.NameResolutionError as e:
                    error_msg = f"DNS resolution error occurred: {e}"
                    #logger.error(error_msg)
                    raise DNSResolutionError(url, e)
                except Exception as e:
                    error_msg = f"An unexpected error occurred: {str(e)}"
                    #logger.error(error_msg)
                    if response.status_code:
                        status_code = response.status_code
                    else:
                        status_code = None
                    #traceback.print_exc()
                    raise DataRequestError(status_code, error_msg)

            batch_size = int(self._default_properties.BATCH_SIZE)
            batch_chunks = [batch[i:i + batch_size] for i in range(0, len(batch), batch_size)]
            responses = []

            with ThreadPoolExecutor(max_workers=5) as executor:
                future_to_batch = {executor.submit(send_batch_request, chunk): chunk for chunk in batch_chunks}

                for future in as_completed(future_to_batch):
                    try:
                        response_data = future.result()
                        if url == self._default_properties.REST_BY_JSON_URL:
                            responses.extend(response_data["GDSSDKResponse"])
                        else:
                            responses.append(response_data)
                    except APIRequestException as e:
                        #logger.error(f"APIException: {e}")
                        raise
                    except Exception as e:
                        #logger.error(f"Batch request failed: {e}")
                        raise

            return {"GDSSDKResponse": responses} if url == self._default_properties.REST_BY_JSON_URL else responses

        except Exception as e:
            logger.error(f"Error while fetching data: {str(e)}")
            raise

    def __get_client_ip(self):
        ip_address = ""
        try:
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
        except Exception as e:
            logger.error(ExceptionMessages.IPADDR_ERROR, exc_info=True)
            traceback.print_exc()
            raise ValueError(e)
        return ip_address
