class ConfigConstants:
    SDK = 'sdk'
    IDENTIFIERS_SIZE = "identifiers_size"
