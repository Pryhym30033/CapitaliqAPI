class TokenServiceConstants:
    HEADERS = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    RESPONSE = "response"
    PASSCODE = 'password'
    USERNAME = 'username'
    STATUS_CODE = "status_code"
    REFRESH_TOKEN = 'refreshToken'
    MISSING_CREDENTIALS = "Username or password is missing"


