import logging
import time

import pandas as pd

from spgmi_api_sdk.dataservices.exceptions.sdk_data_services_exceptions import APIErrorException

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class DataTransformUtil:

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def aggregate_response(self, response):
        #print(f"response {response}")
        values = {}
        start_time = time.time()
        try:
            if "GDSSDKResponse" in response:
                for item in response["GDSSDKResponse"]:
                    #print(f"item {item}")
                    if item["ErrMsg"] == "":
                        mnemonic = item["Mnemonic"]
                        identifier = item["Identifier"]

                        if mnemonic not in values:
                            values[mnemonic] = {}

                        if identifier not in values[mnemonic]:
                            values[mnemonic][identifier] = []

                        if item["Function"] == "GDSP":
                            row_data = item["Rows"][0]["Row"]
                            values[mnemonic][identifier].append(row_data)

                        elif item["Function"] == "GDST":
                            pair = [
                                [row, header]
                                for row, header in zip(
                                    item["Rows"][0]["Row"], item["Headers"]
                                )
                            ]
                            values[mnemonic][identifier].extend(pair)

                        elif item["Function"] == "GDSHE":
                            row_data = [
                                [row["Row"][0], row["Row"][1]]
                                for row in item["Rows"]
                            ]
                            values[mnemonic][identifier].extend(row_data)

                        elif item["Function"] == "GDSPV":
                            row_data = [row["Row"] for row in item["Rows"]]
                            values[mnemonic][identifier].extend(row_data)

                    else:
                        mnemonic = item.get("Mnemonic", "GeneralError")
                        identifier = item.get("Identifier", "ErrMsg")

                        if mnemonic not in values:
                            values[mnemonic] = {}

                        values[mnemonic][identifier] = [[item["ErrMsg"]]]

            else:
                values = [[response]]

            # end_time = time.time()
            # time_taken = end_time - start_time
            #print(f"aggr response time: {time_taken} seconds")

        except Exception as e:
            values = [[str(e)]]

        #print(f"values {values}")
        return values

    @staticmethod
    def process_identifiers_in_dataframe(df, identifier_mapping):
        """
        Processes the 'Identifier' column in the given DataFrame:
        - Expands duplicate mappings.
        - Ensures all user-specified identifiers are present.
        - Removes rows with identifiers not in the user-provided list.
        - Sorts the DataFrame based on the original identifier order.

        :param df: Pandas DataFrame containing the 'Identifier' column.
        :param identifier_mapping: Dictionary mapping user identifiers to internal identifiers.
        :return: Processed DataFrame with valid identifiers and sorted order.
        """

        reverse_mapping = {}
        for k, v in identifier_mapping.items():
            reverse_mapping.setdefault(v, []).append(k)

        df['Identifier'] = df['Identifier'].apply(lambda x: reverse_mapping.get(x, [x]))
        df = df.explode('Identifier', ignore_index=True)

        df['Identifier'] = df['Identifier'].astype(str).str.lower()
        user_identifiers = [uid.lower() for uid in identifier_mapping.keys()]

        existing_identifiers = set(df['Identifier'])
        missing_identifiers = [uid for uid in user_identifiers if uid not in existing_identifiers]

        if missing_identifiers:
            missing_df = pd.DataFrame({col: [None] * len(missing_identifiers) for col in df.columns})
            missing_df['Identifier'] = missing_identifiers
            df = pd.concat([df, missing_df], ignore_index=True)

        df['Identifier'] = df['Identifier'].map({uid.lower(): uid for uid in identifier_mapping.keys()})

        df['Identifier'] = pd.Categorical(df['Identifier'], categories=identifier_mapping.keys(), ordered=True)

        df = df.sort_values('Identifier').reset_index(drop=True)
        df.index = df.index + 1
        return df

    def check_api_errors(response):
        """Checks for API errors in the response and raises a custom exception if found."""
        if isinstance(response, dict) and "GeneralError" in response:
            error_message = response["GeneralError"].get("ErrMsg", "Unknown Error")

            if isinstance(error_message, list):
                error_message = " ".join(map(str, error_message))

            error_message_upper = error_message.upper()

            if any(term in error_message_upper for term in ["DAILY", "HOURLY", "MONTHLY", "EXCEEDED"]):
                raise APIErrorException(error_message, status_code=429)
            raise APIErrorException(error_message)