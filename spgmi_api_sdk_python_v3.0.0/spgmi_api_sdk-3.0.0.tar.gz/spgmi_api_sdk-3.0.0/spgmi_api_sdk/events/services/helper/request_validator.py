from spgmi_api_sdk.events.constants.error_messages import ErrorMessages
from spgmi_api_sdk.events.constants.property_constants import PropertyConstants
import logging

logger = logging.getLogger(__name__)


class RequestValidator:
    def __init__(self):
        self.error_messages = ErrorMessages()
        self.property_constants = PropertyConstants()

    def validate_request(self, identifiers):
        error_messages = []

        # Validate that identifiers is a list with at least one identifier
        if not isinstance(identifiers, list) or not identifiers or not all(
                isinstance(identifier, str) for identifier in identifiers):
            error_message = self.error_messages.identifiers_format_error
            logger.error(error_message)
            error_messages.append(error_message)



        # Validate the size of the identifiers list
        identifiers_size = self.property_constants.identifiers_size
        if len(identifiers) > int(identifiers_size):
            error_message = self.error_messages.identifiers_list_size_exceeded_error
            logger.error(error_message)
            error_messages.append(error_message)



        return error_messages
