from abc import ABC, abstractmethod
import pandas as pd

class EsgScoresServicesInterface(ABC):

    @abstractmethod
    def get_esg_scores(self, token, identifiers, assessment_year=None, proxy=None) -> pd.DataFrame:
        pass