class PropertyConstants:
    _IDENTIFIERS_SIZE = 10

    @property
    def identifiers_size(self):
        return self._IDENTIFIERS_SIZE

