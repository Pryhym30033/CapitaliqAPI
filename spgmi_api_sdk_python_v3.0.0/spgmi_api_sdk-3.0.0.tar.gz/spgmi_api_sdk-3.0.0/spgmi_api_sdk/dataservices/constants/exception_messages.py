
class ExceptionMessages:
    UNAUTHORIZED_MESSAGE = "Unauthorized"
    SERVICE_DOWN = "Service down"
    IPADDR_ERROR = "Exception occurred while getting the IP address"