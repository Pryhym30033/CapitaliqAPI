class FunctionConstants:
    _company_name_to_id_function = "GDSPV"
    _ticker_id_function = "GDSP"
    identifier_conversion_function = "GDSPV"

