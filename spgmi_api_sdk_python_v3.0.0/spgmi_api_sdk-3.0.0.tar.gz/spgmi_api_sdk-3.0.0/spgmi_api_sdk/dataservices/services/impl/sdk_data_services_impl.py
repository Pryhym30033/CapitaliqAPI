from spgmi_api_sdk.dataservices.services.sdk_data_services import SDKDataServicesInterface
from spgmi_api_sdk.dataservices.services.helper.data_transform_util import DataTransformUtil
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties


import logging.config

# Get the logger
logger = logging.getLogger(__name__)

class SDKDataServices(SDKDataServicesInterface):
    def __init__(self):
        self._request_director = RequestDirector()
        self._data_transform_util = DataTransformUtil()
        DefaultProperties._set_default_properties()
        self._default_properties = DefaultProperties()


    def _invoke_data_service(self, sdk_input_request):
        results = {}

        results = self.__process_results(
            sdk_input_request.bearer_token, sdk_input_request.sdk_proxy,
            sdk_input_request.data_requests.function,
            sdk_input_request.data_requests.identifiers, sdk_input_request.data_requests.mnemonics,
            sdk_input_request.data_requests.properties
        )
        DataTransformUtil.check_api_errors(results)

        return results

    def _invoke_data_service_with_payload(self, bearer_token, sdk_proxy, payload):
        responses=RequestDirector._send_sdk_request(self._request_director,bearer_token,sdk_proxy,True,payload)
        result = DataTransformUtil.aggregate_response(self._data_transform_util, responses)

        if isinstance(result, list) and all(isinstance(d, dict) for d in result):
            final_result = {key: value for d in result for key, value in d.items()}
        else:
            final_result = result
        DataTransformUtil.check_api_errors(final_result)

        return final_result


    def __process_results(self, bearer_token, sdk_proxy, function, identifiers, mnemonics, properties):
        result = []
        api_responses = RequestDirector._execute_in_batch(self._request_director, bearer_token, sdk_proxy, function,
                                                                        identifiers, mnemonics, properties)
        threads = []

        def process_response(api_response):
            result.append(DataTransformUtil.aggregate_response(self._data_transform_util, api_response))


        result = DataTransformUtil.aggregate_response(self._data_transform_util, api_responses)


        if isinstance(result, list) and all(isinstance(d, dict) for d in result):

            return {key: value for d in result for key, value in d.items()}
        else:
            return result

    def _convert_snl_ids_to_ciq(self, token, identifiers, proxy):
        """ Converts SNL IDs to CIQ IDs using a batch API request. """
        snl_ids = [identifier for identifier in identifiers if identifier.lower().startswith("snl") and identifier[3:].isdigit()]

        if not snl_ids:
            return {identifier: identifier for identifier in identifiers}

        payload = self._default_properties.generate_convertid_request_payload(snl_ids)

        try:
            transaction_identifier_response = self._invoke_data_service_with_payload(token, proxy, payload)
            snl_to_ciq_mapping = {}
            conversion_data = transaction_identifier_response.get("BECRS_ENTITY_BASE", {})

            for snl_id, values in conversion_data.items():
                if values and isinstance(values, list) and isinstance(values[0], list):
                    ciq_id = values[0][0]
                    snl_to_ciq_mapping[snl_id] = f"IQ{ciq_id}".upper()
            return {identifier: snl_to_ciq_mapping.get(identifier, identifier) for identifier in identifiers}
        except Exception as e:
            raise



    def _convert_all_ids_to_ciq(self, token, identifiers, proxy):
        """ Converts all IDs to CIQ IDs using a batch API request. """
        ids_to_convert = [identifier for identifier in identifiers if not identifier.lower().startswith("iq")]

        if not ids_to_convert:

            return {identifier: identifier for identifier in identifiers}  # Return as is if no conversion needed

        payload = self._default_properties.generate_convertid_request_payload(ids_to_convert)

        try:
            transaction_identifier_response = self._invoke_data_service_with_payload(token, proxy, payload)
            id_to_ciq_mapping = {}
            conversion_data = transaction_identifier_response.get("BECRS_ENTITY_BASE", {})

            for original_id, values in conversion_data.items():
                if values and isinstance(values, list) and isinstance(values[0], list):
                    ciq_id = values[0][0]
                    id_to_ciq_mapping[original_id] = f"IQ{ciq_id}"  # Append "IQ" prefix

            return {identifier: id_to_ciq_mapping.get(identifier, identifier) for identifier in identifiers}
        except Exception as e:
           raise


    def _convert_all_ids_to_snl(self, token, identifiers, proxy):
        """ Converts all IDs to SNL IDs using a batch API request. """
        ids_to_convert = [identifier for identifier in identifiers if not identifier.lower().startswith("snl")]

        if not ids_to_convert:
            return {identifier: identifier for identifier in identifiers}

        payload = self._default_properties.generate_convertid_request_payload(ids_to_convert)

        try:
            transaction_identifier_response = self._invoke_data_service_with_payload(token, proxy, payload)
            id_to_snl_mapping = {}
            conversion_data = transaction_identifier_response.get("BECRS_ENTITY_BASE", {})

            for original_id, values in conversion_data.items():
                snl_id = None
                for value in values:
                    if isinstance(value, list) and len(value) > 3 and value[2] == 'SNL Institution ID':
                        snl_id = value[3]
                        break

                if snl_id:
                    id_to_snl_mapping[original_id] = f"SNL{snl_id}"
                else :
                    snl_id=values[0][0]
                    id_to_snl_mapping[original_id] = f"{snl_id}"

            return {identifier: id_to_snl_mapping.get(identifier, identifier) for identifier in identifiers}
        except Exception as e:
            raise

