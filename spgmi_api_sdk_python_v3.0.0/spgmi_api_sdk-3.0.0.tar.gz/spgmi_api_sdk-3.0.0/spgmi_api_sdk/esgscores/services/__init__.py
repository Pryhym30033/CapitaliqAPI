from spgmi_api_sdk.esgscores.services.impl.sdk_esgscores_services_impl import SDKEsgScoresServices

