from abc import ABC, abstractmethod
import pandas as pd

class KenshoServicesInterface(ABC):

    @abstractmethod
    def get_company_name_to_id(self, token, identifiers, identifier_type=None,  proxy=None) -> pd.DataFrame:
        pass