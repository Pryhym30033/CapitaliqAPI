import traceback
import pandas as pd
import logging

logger = logging.getLogger(__name__)

class DataFormat:
    @staticmethod
    def gettransactions_response_to_dataframe(identifier_mapping, transaction_identifier_mapping, transaction_response):
        data = []
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            for user_identifier, internal_ciq_id in identifier_mapping.items():
                transactions = transaction_identifier_mapping.get(internal_ciq_id, [])

                for transaction in transactions:
                    data.append([
                        user_identifier,
                        transaction,
                        transaction_response.get('IQ_TR_TRANSACTION_TYPE', {}).get(transaction, [['']])[0][0],
                        transaction_response.get('IQ_TR_DEAL_RESOLUTION', {}).get(transaction, [['']])[0][0],
                        transaction_response.get('IQ_TR_TOTALVALUE', {}).get(transaction, [['']])[0][0],
                        transaction_response.get('IQ_TR_ANN_DATE', {}).get(transaction, [['']])[0][0],
                        transaction_response.get('IQ_TR_CLOSED_DATE', {}).get(transaction, [['']])[0][0]
                    ])

            df = pd.DataFrame(data, columns=[
                "Identifier",
                "IQ_TRANSACTION_LIST (Transaction List)",
                "IQ_TR_TRANSACTION_TYPE (Transaction type)",
                "IQ_TR_DEAL_RESOLUTION (Transaction description)",
                "IQ_TR_TOTALVALUE (Transaction Value)",
                "IQ_TR_ANN_DATE (Transaction announcement date)",
                "IQ_TR_CLOSED_DATE (Transaction complete date)"
            ])
            df["IQ_TR_DEAL_RESOLUTION (Transaction description)"] = (
                df["IQ_TR_DEAL_RESOLUTION (Transaction description)"]
                .astype(str)
                .apply(lambda x: x.replace("$", "\\$"))  # Escape $
            )

            df.index = df.index + 1

            '''identifier_color = 'lightblue'
            mnemonic_color = 'lightyellow'

            header_styles = [
                {'selector': f'th.col0', 'props': [('background-color', identifier_color), ('text-align', 'center'),
                                                   ('border', '1px solid black')]},
            ]

            for i in range(1, len(df.columns)):
                header_styles.append({'selector': f'th.col{i}', 'props': [('background-color', mnemonic_color),
                                                                          ('text-align', 'center'),
                                                                          ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                    {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df
        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e
