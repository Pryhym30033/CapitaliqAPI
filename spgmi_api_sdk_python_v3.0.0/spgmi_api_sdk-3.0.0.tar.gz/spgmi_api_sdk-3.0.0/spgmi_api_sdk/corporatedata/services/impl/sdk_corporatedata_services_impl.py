import traceback
from urllib.error import HTTPError

from spgmi_api_sdk.corporatedata.services.helper.data_transform import DataFormat
from spgmi_api_sdk.corporatedata.services.corporatedata_services_interface import CorporateDataServicesInterface
from spgmi_api_sdk.corporatedata.services.helper.corporatedata_request_utils import CorporateDataRequestUtils
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.corporatedata.util.logging_utils import LoggingUtils
from spgmi_api_sdk.corporatedata.services.helper.request_validator import RequestValidator

import logging.config

LoggingUtils.load_logging_config()

logger = logging.getLogger(__name__)


class SDKCorporateDataServices(CorporateDataServicesInterface):

    def __init__(self):
        self.corporate_data_utils = CorporateDataRequestUtils()
        self.data_services = SDKDataServices()
        self.request_validator = RequestValidator()

    def get_corporate_data(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            ipo_identifier_payload = self.corporate_data_utils.generate_corporate_data_ipo_identifier_payload(identifiers_converted)
            ipo_identifier_response = self.data_services._invoke_data_service_with_payload(token, proxy,
                                                                                            ipo_identifier_payload
                                                                                            )
            ipo_identifier_mapping, internal_transid_identifiers = self.extract_ipo_identifiers(ipo_identifier_response)
            payloads=self.corporate_data_utils.generate_corporate_data_payloads(identifiers_converted,internal_transid_identifiers)
            response=self.data_services._invoke_data_service_with_payload(token,proxy,payloads)
            df = DataFormat.getcorporate_data_response_to_dataframe(response, ipo_identifier_mapping,identifier_mapping)
            return df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def extract_ipo_identifiers(self, ipo_identifier_response):
        """
        Extract IPO identifier mapping and internal identifiers from the IPO response.

        Args:
            ipo_identifier_response (dict): The response containing IPO transaction IDs.

        Returns:
            A dictionary mapping user given Identifiers to internal IDs and a list of internal identifiers.
        """
        ipo_identifier_mapping = {
            user_id: internal_id[0]
            for user_id, internal_id in ipo_identifier_response.get(
                "IQ_TR_IPO_TRANSACTION_ID", {}
            ).items()
        }
        internal_identifiers = [internal_id[0] for internal_id in ipo_identifier_mapping.values()]
        return ipo_identifier_mapping, internal_identifiers
