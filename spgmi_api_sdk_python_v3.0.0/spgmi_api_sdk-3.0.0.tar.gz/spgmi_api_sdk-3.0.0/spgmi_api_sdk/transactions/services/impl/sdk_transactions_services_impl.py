import traceback
from requests import HTTPError

import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.transactions.services.helper.data_transform import DataFormat
from spgmi_api_sdk.transactions.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.transactions.services.helper.transactions_request_utils import TransactionDataRequestUtils
from spgmi_api_sdk.transactions.services.sdk_transactions_interface import TransactionsServicesInterface
from spgmi_api_sdk.transactions.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)



class SDKTransactionsServices(TransactionsServicesInterface):

    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_validator = RequestValidator()
        self.trans_request_utils = TransactionDataRequestUtils()

    def get_transactions(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_generic_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            internal_identifiers = list(identifier_mapping.values())

            transaction_identifier_payload = self.trans_request_utils.generate_trans_list_request_payload(internal_identifiers)
            transaction_identifier_response = self.data_services._invoke_data_service_with_payload(
                token, proxy, transaction_identifier_payload
            )

            transaction_identifier_mapping, all_transaction_ids = self.extract_transaction_identifiers(
                transaction_identifier_response
            )
            payload=self.trans_request_utils.generate_trans_request_payload(all_transaction_ids)
            response = self.data_services._invoke_data_service_with_payload(token, proxy,
                                                                             payload)
            df = DataFormat.gettransactions_response_to_dataframe(identifier_mapping, transaction_identifier_mapping,
                                                                  response)
            return df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def extract_transaction_identifiers(self, transaction_identifier_response):
        transaction_identifier_mapping = {
            key: list(dict.fromkeys(txn[0] for txn in value))
            for key, value in transaction_identifier_response['IQ_TRANSACTION_LIST'].items()
        }

        all_transaction_ids = list(dict.fromkeys(
            txn_id for txn_list in transaction_identifier_mapping.values() for txn_id in txn_list
        ))

        return transaction_identifier_mapping, all_transaction_ids


