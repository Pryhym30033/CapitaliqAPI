import traceback
from urllib.error import HTTPError

from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput
from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataRequest
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.financials.constants.data_config import DataConfig
from spgmi_api_sdk.financials.constants.error_messages import ErrorMessages
from spgmi_api_sdk.financials.exception.financials_exception import InvalidMnemonicError
from spgmi_api_sdk.financials.services.helper.data_transform import DataFormat
from spgmi_api_sdk.financials.services.financial_services_interface import FinancialServicesInterface
from spgmi_api_sdk.financials.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.financials.util.logging_utils import LoggingUtils
from spgmi_api_sdk.financials.constants.property_constants import PropertyConstants
import logging.config

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class SDKFinancialServices(FinancialServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.data_config = DataConfig()
        self.error_messages = ErrorMessages()
        self.property_constants = PropertyConstants()
        self.request_validator = RequestValidator()

    def get_income_statement_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_income_statement_pit_function()
        mnemonics = self.data_config.get_income_statement_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_income_statement_historical(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_income_statement_historical_function()
        mnemonics = self.data_config.get_income_statement_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_balance_sheet_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_balance_sheet_pit_function()
        mnemonics = self.data_config.get_balance_sheet_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_balance_sheet_historical(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_balance_sheet_historic_function()
        mnemonics = self.data_config.get_balance_sheet_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_cash_flow_pit(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_cash_flow_pit_function()
        mnemonics = self.data_config.get_cash_flow_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_cash_flow_historical(self, token, identifiers, properties={}, proxy=None):
        function = self.data_config.get_cash_flow_historical_function()
        mnemonics = self.data_config.get_cash_flow_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_financials_pit(self, token, identifiers, mnemonics, properties={}, proxy=None):
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        invalid_mnemonics = [item for item in mnemonics if
                             item.lower() not in map(str.lower, self.data_config.get_all_financial_data_mnemonics())]
        common_mnemonics = [item for item in mnemonics if
                            item.lower() in map(str.lower, self.data_config.get_all_financial_data_mnemonics())]
        if invalid_mnemonics:
            logger.info("The following mnemonic(s) are not applicable with the function: %s", invalid_mnemonics)
            if common_mnemonics:
                mnemonics = common_mnemonics
            else:
                logger.error(self.error_messages.mnemonic_not_supported_error)
                raise InvalidMnemonicError(self.error_messages.mnemonic_not_supported_error)
        function = self.data_config.get_financials_pit_function()
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_pit(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_financials_historical(self, token, identifiers, mnemonics, properties={}, proxy=None):
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        invalid_mnemonics = [item for item in mnemonics if
                             item.lower() not in map(str.lower, self.data_config.get_all_financial_data_mnemonics())]
        common_mnemonics = [item for item in mnemonics if
                            item.lower() in map(str.lower, self.data_config.get_all_financial_data_mnemonics())]
        if invalid_mnemonics:
            logger.info("The following mnemonic(s) are not applicable with the function: %s", invalid_mnemonics)
            if common_mnemonics:
                mnemonics = common_mnemonics
            else:
                logger.error(self.error_messages.mnemonic_not_supported_error)
                raise InvalidMnemonicError(self.error_messages.mnemonic_not_supported_error)
        function = self.data_config.get_financials_historical_function()
        sdk_data_request = self.__create_sdk_data_request(identifiers, function, properties, mnemonics)
        sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
        try:
            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output, properties)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def get_financials(self, token, identifiers, period_type=None, proxy=None):
        function = self.data_config.get_financials_function()
        mnemonics = self.data_config.get_financial_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers, mnemonics)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")

        properties = {"metaDataTag": "periodDate"}
        if period_type:
            properties.update({"periodType": period_type})

        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())
            sdk_data_request = self.__create_sdk_data_request(identifiers_converted, function, properties,
                                                              mnemonics=mnemonics)
            sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)

            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_get_financials_to_dataframe(final_output,identifier_mapping=identifier_mapping, caption=
                                                       self.data_config.get_financials_data_mnemonics_caption())

            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input