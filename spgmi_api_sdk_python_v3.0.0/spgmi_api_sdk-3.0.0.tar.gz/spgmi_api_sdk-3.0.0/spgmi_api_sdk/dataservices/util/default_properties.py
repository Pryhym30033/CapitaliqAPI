import logging
from spgmi_api_sdk.dataservices.util.property_utils import PropertyUtils
from spgmi_api_sdk.dataservices.constants.sdk_constants import SDKConstants
logger = logging.getLogger(__name__)

class DefaultProperties:
    REST_BY_JSON_URL = None
    BATCH_SIZE = -1
    SDK_CLIENT_VERSION = None
    MAX_THREADS = -1
    ESG_ENDPOINT_URL = None
    TRUCOST_ENV_ENDPOINT_URL = None
    CIQ_ENDPOINT_URL = None
    PARIS_ALIGNMENT_URL = None
    TRUCOST_CEAR_URL = None
    PHYSICAL_RISK_URL = None
    AGENCY_RATINGS_URL = None
    FILINGS_ENDPOINT_URL = None
    TRANSCRIPTS_ENDPOINT_URL = None

    @staticmethod
    def _set_default_properties():
        try:
            DefaultProperties.REST_BY_JSON_URL = PropertyUtils._get_property(SDKConstants.SDK, SDKConstants.SDK_REST_JSON_URL)
            #logger.info(f"SDK JSON URL is configured with : {DefaultProperties.REST_BY_JSON_URL}")

            DefaultProperties.SDK_CLIENT_VERSION = PropertyUtils._get_property(SDKConstants.SDK, SDKConstants.PROP_CLIENT_VERSION)
            #logger.info(f"SDK Client Library VERSION is configured with : {DefaultProperties.SDK_CLIENT_VERSION}")

            DefaultProperties.BATCH_SIZE = PropertyUtils._get_property(SDKConstants.SDK, SDKConstants.BATCH_SIZE)
            #logger.info(f"SDK Client Batch Size is configured with : {DefaultProperties.BATCH_SIZE}")

            DefaultProperties.MAX_THREADS = PropertyUtils._get_property(SDKConstants.SDK, SDKConstants.MAX_THREADS)
            #logger.info(f"SDK Client max threads is configured with : {DefaultProperties.MAX_THREADS}")

            DefaultProperties.ESG_ENDPOINT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                             SDKConstants.ESG_ENDPOINT_URL)

            DefaultProperties.TRUCOST_ENV_ENDPOINT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                                     SDKConstants.TRUCOST_ENV_ENDPOINT_URL)

            DefaultProperties.CIQ_ENDPOINT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                             SDKConstants.CIQ_ENDPOINT_URL)

            DefaultProperties.PARIS_ALIGNMENT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                                SDKConstants.PARIS_ALIGNMENT_URL)

            DefaultProperties.PARIS_ALIGNMENT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                                SDKConstants.PARIS_ALIGNMENT_URL)

            DefaultProperties.TRUCOST_CEAR_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                             SDKConstants.TRUCOST_CEAR_URL)

            DefaultProperties.PHYSICAL_RISK_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                              SDKConstants.PHYSICAL_RISK_URL)


            DefaultProperties.AGENCY_RATINGS_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                               SDKConstants.AGENCY_RATINGS_URL)

            DefaultProperties.FILINGS_ENDPOINT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                                 SDKConstants.FILINGS_ENDPOINT_URL)

            DefaultProperties.TRANSCRIPTS_ENDPOINT_URL = PropertyUtils._get_property(SDKConstants.SDK,
                                                                                     SDKConstants.TRANSCRIPTS_ENDPOINT_URL)





        except Exception as e:
            logger.error("Error while reading default properties from spciq-api-dataservices-application.properties. Please set the properties properly.", exc_info=True)

    @staticmethod
    def generate_convertid_request_payload(ids,function='GDSPV'):
        convertid_payload = []

        desired_order = [
            ("BECRS_ENTITY_BASE", "Convertion ID")
        ]

        for mnemonic, caption in desired_order:
            for id in ids:
                properties = {}
                payload = {
                    "identifier":id,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                convertid_payload.append(payload)

        return convertid_payload
