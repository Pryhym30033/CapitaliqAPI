class PropertyNotFoundError(Exception):
    pass

class IdentifiersListSizeExceededError(Exception):
    def __init__(self, message="The 'identifiers' list should not contain more than 10 items."):
        self.message = message
        super().__init__(self.message)