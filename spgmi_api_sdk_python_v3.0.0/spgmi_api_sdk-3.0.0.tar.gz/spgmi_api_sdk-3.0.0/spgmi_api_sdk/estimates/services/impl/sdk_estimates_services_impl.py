import traceback
from requests import HTTPError

import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.estimates.services.sdk_estimates_interface import EstimatesServicesInterface
from spgmi_api_sdk.estimates.services.helper.estimates_request_utils import EstimatesRequestUtils
from spgmi_api_sdk.estimates.services.helper.data_transform import DataFormat
from spgmi_api_sdk.estimates.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.estimates.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class SDKEstimatesServices(EstimatesServicesInterface):

    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_validator = RequestValidator()
        self.estimates_request_utils = EstimatesRequestUtils()

    def get_estimates(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_generic_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            payload = self.estimates_request_utils.generate_estimates_request_payload(identifiers_converted)
            response = self.data_services._invoke_data_service_with_payload(token, proxy, payload)
            df = DataFormat.getestimates_response_to_dataframe(response, identifier_mapping)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e
