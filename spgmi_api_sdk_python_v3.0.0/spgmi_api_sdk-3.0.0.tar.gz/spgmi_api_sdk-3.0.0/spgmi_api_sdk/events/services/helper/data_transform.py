import numpy as np
import pandas as pd
import traceback
import logging
from datetime import datetime, date, timedelta

from spgmi_api_sdk.dataservices.services.helper.data_transform_util import DataTransformUtil
from spgmi_api_sdk.events.constants.error_messages import ErrorMessages

logger = logging.getLogger(__name__)

class DataFormat:
    def __init__(self):
        self.error_messages = ErrorMessages()

    def _convert_to_dataframe_pitv(self, data, historical=False):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        flattened_data = {}
        all_subkeys = set()
        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]
            rows = []

            for sub_key, main_key_data in flattened_data.items():


                # Set max length to last 3 elements (or fewer if not available)
                max_length = min(3, max(len(values) for values in main_key_data.values()))

                for i in range(max_length):
                    row = {'Identifier': sub_key}

                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if historical:
                            values = values[-3:]
                        else:
                            values = values[:3]



                        if i < len(values):
                            row[main_key] = values[i][0]


                        else:
                            row[main_key] = ''


                    rows.append(row)

            df = pd.DataFrame(rows)

            columns_order = [col for col in df.columns]

            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            # raise e
            traceback.print_exc()
            # return None
            raise e


    def _convert_to_dataframe_pit(self,data):

        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()
        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []

            for sub_key, main_key_data in flattened_data.items():


                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'IQ_EVENT_ID': sub_key}

                    for main_key in data.keys():
                        values = main_key_data[main_key]


                        if i < len(values):
                            if main_key=='IQ_EVENT_DATE':
                                datetime_str = values[i][0]
                                try:

                                    dt_obj = datetime.strptime(datetime_str, '%m/%d/%Y %I:%M:%S %p')
                                    values[i][0] = dt_obj.strftime('%Y-%m-%d %H:%M:%S')
                                except ValueError:
                                    # If parsing fails, keep the original value
                                    values[i][0] = datetime_str

                            row[main_key] = values[i][0]




                        else:
                            row[main_key] = ''


                    rows.append(row)

            df = pd.DataFrame(rows)



            columns_order = [col for col in df.columns]
            df = df[columns_order]
            df.index = range(1, len(df) + 1)

            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            # raise e
            traceback.print_exc()
            # return None
            raise e



    def _merge_response(self,data1,data2,identifier_mapping,caption={}):

        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            # Merge the DataFrames
            merged_df = pd.merge(data1, data2, on="IQ_EVENT_ID", how="left")



            merged_df.reset_index(inplace=True)
            # merged_df['Identifier'] = merged_df['Identifier'].replace({v: k for k, v in identifier_mapping.items()})
            if identifier_mapping:
                merged_df= DataTransformUtil.process_identifiers_in_dataframe(merged_df,identifier_mapping)
            if 'IQ_EVENT_DATE' in merged_df.columns:
                merged_df = merged_df.sort_values(by=['Identifier', 'IQ_EVENT_DATE'], ascending=[True, False]).reset_index(drop=True)
            merged_df.index = merged_df.index + 1

            if caption:
                new_columns = {}
                for col in merged_df.columns:
                    if col in caption:
                        new_columns[col] = f"{col} ({caption[col]})"
                    else:
                        new_columns[col] = col
                # Rename the columns
                merged_df.rename(columns=new_columns, inplace=True)

            event_id_col = "IQ_EVENT_ID (Event ID)"
            merged_df["IQ_EVENT_TYPE (Type)"] = merged_df["IQ_EVENT_TYPE (Type)"].where(
                ~merged_df["IQ_EVENT_TYPE (Type)"].isin(["nan", "NaN"]),
                merged_df["IQ_EVENT_ID (Event ID)"]
            )
            merged_df = merged_df.apply(lambda row: row.fillna(row[event_id_col]), axis=1)

            columns_order = ['Identifier'] + ['IQ_EVENT_ID (Event ID)'] + ['IQ_EVENT_DATE (Date)'] + ['IQ_EVENT_TYPE (Type)']

            df = merged_df[columns_order]



            df.index = range(1, len(df) + 1)


            '''response_color = 'lightyellow'
            identifier_color = 'lightblue'


            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', identifier_color), ('text-align', 'center'),
                           ('border', '1px solid black')]}
            ]

            # Add styles for all columns
            for i, col in enumerate(columns_order, start=1):  # Start at 1 for index alignment
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            df = df.drop_duplicates().reset_index(drop=True)
            df.index = df.index + 1
            return df




        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            # raise e
            traceback.print_exc()
            # return None
            raise e

