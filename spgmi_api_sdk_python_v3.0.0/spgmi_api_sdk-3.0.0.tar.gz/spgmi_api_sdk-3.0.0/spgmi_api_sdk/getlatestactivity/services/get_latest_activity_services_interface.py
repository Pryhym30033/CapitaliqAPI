from abc import ABC, abstractmethod
import pandas as pd

class GetLatestActivityServicesInterface(ABC):

    @abstractmethod
    def get_latest_activity(self, token, identifiers,  proxy=None) -> pd.DataFrame:
        pass