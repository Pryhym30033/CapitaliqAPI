class Constants:
    class Functions:
        GDSP = "GDSP"
        GDST = "GDST"
        GDSPV = "GDSPV"
        GDSHE = "GDSHE"

