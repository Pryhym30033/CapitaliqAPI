
DEFAULT_PROPERTIES = {
    'sdk': {
        'api_endpoint_url': 'https://api-ciq.marketintelligence.spglobal.com/gdsapi/rest/v3/clientservice.json',
        'esg_endpoint_url': 'https://xpressapi.marketplace.spglobal.com/esgscores/api/v2/esg/scores',
        'trucost_env_endpoint_url': 'https://xpressapi.marketplace.spglobal.com/trucostenvironmental/api/v1/company/environmental',
        'ciq_endpoint_url': 'https://api-ciq.marketintelligence.spglobal.com/gdsapi/rest/v3/clientservice.json',
        'paris_alignment_url': 'https://xpressapi.marketplace.spglobal.com/trucostparisalignment/api/v1/parisalignment',
        'trucost_cear_url': 'https://xpressapi.marketplace.spglobal.com/trucostcear/api/v1/carbonearningsatrisk',
        'physical_risk_url': 'https://xpressapi.marketplace.spglobal.com/physicalrisk/api/v1/company/physicalrisks',
        'agency_ratings_url': 'https://xpressapi.marketplace.spglobal.com/agencyratings/api/v1/issuer',
        'filings_endpoint_url': 'https://api-ciq.marketintelligence.spglobal.com/gds/documents/api/v1/search?docType=FILINGS_DOCUMENTS_API',
        'transcripts_endpoint_url': 'https://api-ciq.marketintelligence.spglobal.com/gds/documents/api/v1/search?docType=TRANSCRIPTS_DOCUMENTS_API'


    }
}