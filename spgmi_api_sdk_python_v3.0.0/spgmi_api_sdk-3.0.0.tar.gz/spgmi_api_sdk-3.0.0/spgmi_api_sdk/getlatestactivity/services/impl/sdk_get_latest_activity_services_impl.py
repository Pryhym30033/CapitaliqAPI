import concurrent.futures
import traceback
from urllib.error import HTTPError

from spgmi_api_sdk.documents.services import SDKDocumentsServices
from spgmi_api_sdk.events.services import SDKEventsServices
from spgmi_api_sdk.getlatestactivity.services.get_latest_activity_services_interface import \
    GetLatestActivityServicesInterface
from spgmi_api_sdk.keydevs.services import SDKKeyDevsServices
from spgmi_api_sdk.getlatestactivity.util.logging_utils import LoggingUtils
import logging.config

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)

class SDKGetLatestActivityServices(GetLatestActivityServicesInterface):
    def __init__(self):
        self.documents = SDKDocumentsServices()
        self.keydev = SDKKeyDevsServices()
        self.events = SDKEventsServices()

    def get_latest_activity(self, token, identifiers, proxy=None):
        try:

            def get_documents_data():
                return self.documents.get_documents(token, identifiers, proxy)

            def get_events_data():
                return self.events.get_events(token, identifiers, proxy)

            def get_keydev_data():
                return self.keydev.get_key_devs(token, identifiers, proxy)

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = {
                    'documents': executor.submit(get_documents_data),
                    'events': executor.submit(get_events_data),
                    'keydev': executor.submit(get_keydev_data),
                }

                documents_output = futures['documents'].result()
                events_output = futures['events'].result()
                keydev_output = futures['keydev'].result()
            return [documents_output, events_output, keydev_output]

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e
