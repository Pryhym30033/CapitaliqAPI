import traceback
from requests import HTTPError

import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.multiples.services.sdk_multiples_interface import MultiplesServicesInterface
from spgmi_api_sdk.multiples.services.helper.multiples_request_utils import MultiplesRequestUtils
from spgmi_api_sdk.multiples.services.helper.data_transform import DataFormat
from spgmi_api_sdk.multiples.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.multiples.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class SDKMultiplesServices(MultiplesServicesInterface):

    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_validator = RequestValidator()
        self.multiples_request_utils = MultiplesRequestUtils()

    def get_multiples(self, token, identifiers, proxy=None):
        error_messages = self.request_validator.validate_generic_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            payload = self.multiples_request_utils.generate_multiples_request_payload(identifiers_converted)
            response = self.data_services._invoke_data_service_with_payload(token, proxy, payload)
            df = DataFormat.getmultiples_response_to_dataframe(response, identifier_mapping)
            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e