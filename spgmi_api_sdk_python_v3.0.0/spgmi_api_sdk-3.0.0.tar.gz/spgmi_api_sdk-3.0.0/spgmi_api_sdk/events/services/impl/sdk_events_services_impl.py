import concurrent.futures

from dateutil.relativedelta import relativedelta

from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput
from spgmi_api_sdk.dataservices.model.sdk_data_request import SDKDataRequest
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
import traceback
from urllib.error import HTTPError
import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.events.constants.data_config import DataConfig
from spgmi_api_sdk.events.services.events_services_interface import EventsServicesInterface
from spgmi_api_sdk.events.services.helper.data_transform import DataFormat
from spgmi_api_sdk.events.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.events.util.logging_utils import LoggingUtils
import pandas as pd
from datetime import datetime, date, timedelta
LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)
class SDKEventsServices(EventsServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_director = RequestDirector()
        self.data_format = DataFormat()
        self.request_validator = RequestValidator()
        self.data_config = DataConfig()

    def get_events(self, token, identifiers, proxy=None):
        events_id_function = self.data_config.get_events_id_function()
        events_id_mnemonics = self.data_config.get_events_id_mnemonics()
        events_function = self.data_config.get_events_function()
        events_mnemonics = self.data_config.get_event_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        current_date = datetime.now().strftime('%m/%d/%Y')
        current_date_2 = (datetime.now() + timedelta(days=1)).strftime('%m/%d/%Y')
        three_months_ago = (datetime.now() - relativedelta(months=3)).strftime('%m/%d/%Y')
        three_months_later = (datetime.now() + relativedelta(months=3)).strftime('%m/%d/%Y')
        historical_properties = {
            "startdate": three_months_ago,
            "enddate": current_date
        }
        future_properties = {
            "startdate": current_date_2,
            "enddate": three_months_later
        }

        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            def get_historical_data():
                sdk_data_request_historical = self.__create_sdk_data_request(
                    identifiers=identifiers_converted, function=events_id_function, mnemonics=events_id_mnemonics,
                    properties=historical_properties)
                sdk_input_request_historical = self.__create_sdk_data_input(token, proxy, sdk_data_request_historical)
                final_output_historical = self.data_services._invoke_data_service(sdk_input_request_historical)
                return self.data_format._convert_to_dataframe_pitv(final_output_historical, True)

            def get_future_data():
                sdk_data_request_future = self.__create_sdk_data_request(
                    identifiers=identifiers_converted, function=events_id_function, mnemonics=events_id_mnemonics,
                    properties=future_properties)
                sdk_input_request_future = self.__create_sdk_data_input(token, proxy, sdk_data_request_future)
                final_output_future = self.data_services._invoke_data_service(sdk_input_request_future)
                return self.data_format._convert_to_dataframe_pitv(final_output_future)

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = {
                    'historical': executor.submit(get_historical_data),
                    'future': executor.submit(get_future_data)
                }
                df_historical = futures['historical'].result()
                df_future = futures['future'].result()

            event_identifiers = df_historical["IQ_EVENT_ID"].tolist() + df_future["IQ_EVENT_ID"].tolist()

            sdk_data_request = self.__create_sdk_data_request(event_identifiers, events_function,
                                                              mnemonics=events_mnemonics)
            sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)
            final_output = self.data_services._invoke_data_service(sdk_input_request)

            df = self.data_format._convert_to_dataframe_pit(final_output)
            merged_df1 = pd.concat([df_historical, df_future], ignore_index=True)
            merged_df2 = self.data_format._merge_response(merged_df1, df, identifier_mapping,
                                                          caption=self.data_config.get_events_data_mnemonics_caption())

            return merged_df2

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input