import logging

from spgmi_api_sdk.corporatedata.constants.sdk_constants import Constants
from spgmi_api_sdk.corporatedata.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()

logger = logging.getLogger(__name__)


class CorporateDataRequestUtils:

    @staticmethod
    def generate_corporate_data_payloads(identifiers,internal_transid_identifiers,function=Constants.Functions.GDSP):
        mnemonics_payload = []
        desired_order = [
            ("IQ_COMPANY_STATUS", "Status"),
            ("IQ_PRIMARY_INDUSTRY", "Primary Industry (CIQ/GICS)"),
            ("BECRS_ENTITY_BASE", "LEI"),
            ("IQ_YEAR_FOUNDED", "Date of Incorporation"),
            ("IQ_PRIMARY_SIC_CODE", "SIC Code"),
            ("BECRS_ENTITY_BIC_CODE", "BIC"),
            ("ISCRS_NAICS", "NAICS Code"),
            ("IQ_BUSINESS_DESCRIPTION", "Company Description"),
            ("IQ_COMPANY_ADDRESS", "Address"),
            ("IQ_COMPANY_PHONE", "Phone"),
            ("IQ_COMPANY_WEBSITE", "Website"),
            ("IQ_PROFESSIONAL", "Professionals"),
            ("IQ_PROFESSIONAL_TITLE","Professionals"),
            ("IQ_GICS_CODE", "GICS Sub-Industry Code"),
            ("IQ_INDUSTRY_SECTOR", "Industry Sector"),
            ("IQ_INDUSTRY_GROUP", "Industry Group"),
            ("IQ_INDUSTRY", "Industry Level"),
            ("IQ_TR_OFFER_DATE", "IPO Date"),
        ]

        for mnemonic, caption in desired_order:
            if mnemonic=="IQ_TR_OFFER_DATE":
                for internal_transid_identifier in internal_transid_identifiers:
                    properties = {}
                    payload = {
                        "identifier": internal_transid_identifier,
                        "mnemonic": mnemonic,
                        "function": function,
                        "properties": properties
                    }
                    mnemonics_payload.append(payload)
            else:
                for identifier in identifiers:

                    properties = {}

                    if mnemonic in ["BECRS_ENTITY_BASE", "BECRS_ENTITY_BIC_CODE", "ISCRS_NAICS"]:
                        function = Constants.Functions.GDSPV
                    elif mnemonic in ["IQ_PROFESSIONAL", "IQ_PROFESSIONAL_TITLE"]:
                        properties["startRank"] = "1"
                        properties["endRank"] = "5"
                        function = Constants.Functions.GDSHE
                    else:
                        function = Constants.Functions.GDSP

                    payload = {
                        "identifier":identifier,
                        "mnemonic": mnemonic,
                        "function": function,
                        "properties": properties
                    }
                    mnemonics_payload.append(payload)

        return mnemonics_payload

    @staticmethod
    def generate_corporate_data_ipo_identifier_payload(identifiers, function=Constants.Functions.GDSP):
        ipo_identifier_payload = []
        desired_order = [
            ("IQ_TR_IPO_TRANSACTION_ID", "IPO Transaction ID")
        ]

        for mnemonic, caption in desired_order:
            for identifier in identifiers:

                properties = {}

                payload = {
                    "identifier": identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                if payload.get("mnemonic") == "IQ_TR_IPO_TRANSACTION_ID":
                    ipo_identifier_payload.append(payload)

        return ipo_identifier_payload

