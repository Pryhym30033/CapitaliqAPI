class MnemonicConstants:

    _events_mnemonics = [
        "IQ_EVENT_TYPE",
        "IQ_EVENT_DATE"
    ]
    _events_mnemonics_captions = {
            "IQ_EVENT_TYPE": "Type",
            "IQ_EVENT_DATE": "Date",
             "IQ_EVENT_ID": "Event ID"
    }

    _events_id_mnemonics = [
        "IQ_EVENT_ID"
    ]



