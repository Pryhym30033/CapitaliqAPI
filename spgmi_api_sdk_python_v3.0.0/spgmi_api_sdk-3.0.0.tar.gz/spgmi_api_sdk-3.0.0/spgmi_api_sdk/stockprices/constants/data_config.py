from spgmi_api_sdk.stockprices.constants.functions_constants import FunctionConstants
from spgmi_api_sdk.stockprices.constants.mnemonics_constants import MnemonicConstants

class DataConfig:


    def get_stock_prices_function(self):
        return FunctionConstants._stock_prices_function

    def get_stock_prices_mnemonics(self):
        return MnemonicConstants._stock_prices_mnemonics

    def get_stock_prices_mnemonics_caption(self):
        return MnemonicConstants._stock_prices_mnemonics_caption




