import traceback

import pandas as pd
import logging
from spgmi_api_sdk.dataservices.services.helper.data_transform_util import DataTransformUtil


logger = logging.getLogger(__name__)

class DataFormat:

    @staticmethod
    def getcorporate_data_response_to_dataframe(response, ipo_identifier_mapping, identifier_mapping):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            data = {'Identifier': list(
                dict.fromkeys(identifier for item in response.values() for identifier in item.keys()))}

            for mnemonic, item in response.items():
                if mnemonic == "IQ_TR_OFFER_DATE":
                    data[mnemonic] = []
                    for identifier in data['Identifier']:
                        ipo_date = None
                        try:
                            internal_id = ipo_identifier_mapping.get(identifier, [identifier])[0]

                            if internal_id == "Data Unavailable" or ipo_identifier_mapping.get(identifier) == [
                                "Data Unavailable"]:
                                ipo_date = "Data Unavailable"
                            else:
                                ipo_data = item.get(internal_id, [[None]])
                                if isinstance(ipo_data, list) and isinstance(ipo_data[0], list) and len(
                                        ipo_data[0]) > 0:
                                    ipo_date = ipo_data[0][0]
                        except Exception as e:
                            logger.error(f"Error extracting IPO date for {internal_id}: {e}")
                        data[mnemonic].append(ipo_date)
                elif mnemonic == "IQ_PROFESSIONAL":
                    data[f"IQ_PROFESSIONAL-IQ_PROFESSIONAL_TITLE"] = []

                    for identifier in data['Identifier']:
                        professional_names = list(dict.fromkeys(
                            dict_row[0] for dict_row in item.get(identifier, []) if dict_row
                        ))

                        titles = list(dict.fromkeys(
                            dict_row[0] for dict_row in
                            response.get("IQ_PROFESSIONAL_TITLE", {}).get(identifier, []) if dict_row
                        ))

                        combined_professionals = list(dict.fromkeys(
                            f"{name} - {title}" if title else name for name, title in
                            zip(professional_names, titles)
                        ))

                        data[f"IQ_PROFESSIONAL-IQ_PROFESSIONAL_TITLE"].append(
                            list(filter(None, combined_professionals))
                        )

                elif "IQ_PROFESSIONAL_TITLE" in mnemonic:
                    continue

                elif mnemonic == "BECRS_ENTITY_BIC_CODE":
                    data[f"{mnemonic}"] = []
                    for identifier in data['Identifier']:
                        try:
                            bic_data = item.get(identifier, [])
                            bic_codes = list(dict.fromkeys(
                                row[3] for row in bic_data if len(row) > 3 and "BIC Code" in row[2]
                            ))
                            if bic_codes:
                                data[f"{mnemonic}"].append(", ".join(bic_codes))
                            elif bic_data and len(bic_data[0]) <= 1:
                                fallback_value = bic_data[0][0] if bic_data[0] else "Data Unavailable"
                                data[f"{mnemonic}"].append(fallback_value)
                            else:
                                data[f"{mnemonic}"].append("Data Unavailable")
                        except Exception as e:
                            logger.error(f"Error processing BIC for identifier {identifier}: {e}")
                            data[f"{mnemonic}"].append(None)



                elif mnemonic == "BECRS_ENTITY_BASE":
                    data[f"{mnemonic}"] = []
                    for identifier in data['Identifier']:
                        try:
                            lei_data = item.get(identifier, [])

                            if lei_data:
                                found_lei = next(
                                    (dict_row[3] for dict_row in lei_data if
                                     len(dict_row) > 3 and "LEI" in dict_row[2]),
                                    None
                                )

                                if found_lei:
                                    data[f"{mnemonic}"].append(found_lei)
                                elif len(lei_data[0]) <= 1:
                                    fallback_value = lei_data[0][0] if lei_data[0] else "Data Unavailable"
                                    data[f"{mnemonic}"].append(fallback_value)
                                else:
                                    data[f"{mnemonic}"].append("Data Unavailable")
                            else:
                                data[f"{mnemonic}"].append("Data Unavailable")
                        except Exception as e:
                            logger.error(f"Error processing LEI for identifier {identifier}: {e}")
                            data[f"{mnemonic}"].append(None)

                elif mnemonic == "ISCRS_NAICS":
                    naics_values = []
                    for identifier in data['Identifier']:
                        try:
                            naics_data = item.get(identifier, [])
                            if naics_data and len(naics_data[0]) > 1:
                                naics_values.append(f"{naics_data[0][0]} - {naics_data[0][1]}")
                            elif naics_data and len(naics_data[0]) <= 1:
                                fallback_value = naics_data[0][0] if naics_data[0] else "Data Unavailable"
                                naics_values.append(fallback_value)
                            else:
                                naics_values.append("Data Unavailable")
                        except Exception as e:
                            logger.error(f"Error processing NAICS for identifier {identifier}: {e}")
                            naics_values.append(None)

                    data[f"{mnemonic}"] = naics_values

                else:
                    data[f"{mnemonic}"] = [
                        next((value[0] for value in item.get(identifier, []) if value), None)
                        for identifier in data['Identifier']
                    ]

            max_len = len(data['Identifier'])
            for key in data:
                if len(data[key]) < max_len:
                    data[key].extend([None] * (max_len - len(data[key])))

            df = pd.DataFrame(data)
            df.index = df.index + 1

            # Remove internal mapping identifiers by filtering out any identifiers in the ipo_identifier_mapping values
            internal_ids = [internal_id for ids in ipo_identifier_mapping.values() for internal_id in ids]
            df = df[~df['Identifier'].isin(internal_ids)]
            if identifier_mapping:
                df= DataTransformUtil.process_identifiers_in_dataframe(df,identifier_mapping)

            desired_order = [
                ("IQ_COMPANY_STATUS", "Status"),
                ("IQ_PRIMARY_INDUSTRY", "Primary Industry (CIQ/GICS)"),
                ("BECRS_ENTITY_BASE", "LEI"),
                ("IQ_YEAR_FOUNDED", "Date of Incorporation"),
                ("IQ_PRIMARY_SIC_CODE", "SIC Code"),
                ("BECRS_ENTITY_BIC_CODE", "BIC"),
                ("ISCRS_NAICS", "NAICS Code"),
                ("IQ_BUSINESS_DESCRIPTION", "Company Description"),
                ("IQ_COMPANY_ADDRESS", "Address"),
                ("IQ_COMPANY_PHONE", "Phone"),
                ("IQ_COMPANY_WEBSITE", "Website"),
                ("IQ_PROFESSIONAL-IQ_PROFESSIONAL_TITLE", "Professionals"),
                ("IQ_GICS_CODE", "GICS Sub-Industry Code"),
                ("IQ_INDUSTRY_SECTOR", "Industry Sector"),
                ("IQ_INDUSTRY_GROUP", "Industry Group"),
                ("IQ_INDUSTRY", "Industry Level"),
                ("IQ_TR_OFFER_DATE", "IPO Date"),
            ]
            for mnemonic, caption in desired_order:
                if mnemonic in df.columns and not df[mnemonic].isnull().all():
                    df.rename(columns={mnemonic: f"{mnemonic} ({caption})"}, inplace=True)

            '''identifier_color = 'lightblue'
            mnemonic_color = 'lightyellow'

            header_styles = [
                {'selector': f'th.col0', 'props': [('background-color', identifier_color), ('text-align', 'center'),
                                                   ('border', '1px solid black')]},
            ]

            for i in range(1, len(df.columns)):
                header_styles.append({'selector': f'th.col{i}', 'props': [('background-color', mnemonic_color),
                                                                          ('text-align', 'center'),
                                                                          ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                    {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e
