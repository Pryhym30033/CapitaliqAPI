import logging

from spgmi_api_sdk.marketdata.constants.functions_constants import Functions
from spgmi_api_sdk.marketdata.util.sdk_utils import SDKUtils
from spgmi_api_sdk.marketdata.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class MarketDataRequestUtils:
    @staticmethod
    def generate_market_data_payloads(identifiers,function=Functions.GDSP):
        mnemonics_payload = []

        desired_order = [
            ("IQ_CLOSEPRICE", "Last (Delayed)"),
            ("IQ_VWAP", "VWAP (Delayed)"),
            ("IQ_OPENPRICE", "Open"),
            ("IQ_CLOSEPRICE", "Previous Close"),
            ("IQ_HIGHPRICE", "Day High"),
            ("IQ_LOWPRICE", "Day Low"),
            ("IQ_YEARHIGH", "52 wk High"),
            ("IQ_YEARLOW", "52 wk Low"),
            ("IQ_BETA_5YR", "Beta 5Y"),
            ("IQ_MARKETCAP", "Market Cap.($M)"),
            ("IQ_TEV", "Total Enterprise Value ($M)"),
            ("IQ_VOLUME", "Volume"),
            ("IQ_VOLUME", "Volume (Avg 3M Daily Volume)"),
            ("IQ_SHARESOUTSTANDING", "Shares Out."),
            ("IQ_FLOAT_PERCENT", "Float (%)"),
            ("IQ_DIVIDEND_YIELD","Div. Yield (%)")
        ]

        for mnemonic, caption in desired_order:
            for identifier in identifiers:
                properties = {}

                if mnemonic == "IQ_CLOSEPRICE" and caption == "Previous Close":
                    properties["asOfDate"] = SDKUtils.get_as_of_date()

                if mnemonic == "IQ_VOLUME" and caption == "Volume (Avg 3M Daily Volume)":
                    properties["startdate"] = SDKUtils.calculate_start_end_dates()[0]
                    properties["enddate"] = SDKUtils.calculate_start_end_dates()[1]
                    function=Functions.GDST
                else:
                    function=Functions.GDSP

                payload = {
                    "identifier":identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                mnemonics_payload.append(payload)

        return mnemonics_payload
