import logging

from spgmi_api_sdk.estimates.constants.functions_constants import Functions
from spgmi_api_sdk.estimates.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class EstimatesRequestUtils:
    @staticmethod
    def generate_estimates_request_payload(identifiers,function=Functions.GDSP):
        mnemonics_payload = []
        desired_order = [
            ("IQ_AVG_BROKER_REC_CIQ", "Recommentation"),
            ("IQ_AVG_BROKER_REC_NO_CIQ", "Recommentation"),
            ("IQ_PRICE_TARGET_CIQ", "Target price"),
            ("IQ_TARGET_PRICE_NUM_CIQ", "# of Analysts"),
            ("IQ_PE_EXCL_FWD_CIQ", "PE"),
            ("IQ_PBV_FWD_CIQ", "P/ BV"),
            ("IQ_PRICE_CFPS_FWD_CIQ", "P/ CFPS"),
            ("IQ_PEG_FWD_CIQ", "PEG"),
            ("IQ_TEV_EBIT_FWD_CIQ", "TEV/ EBIT"),
            ("IQ_EPS_NORM_EST_CIQ", "EPS ($)"),
            ("IQ_REVENUE_EST_CIQ", "Revenue ($000)"),
            ("IQ_EBITDA_EST_CIQ", "EBITDA ($000)")
        ]
        gdshe_mnemonics = ["IQ_EPS_NORM_EST_CIQ", "IQ_REVENUE_EST_CIQ", "IQ_EBITDA_EST_CIQ"]
        period_types = ['IQ_FQ', 'IQ_FQ+1', 'IQ_FY', 'IQ_FY+1', 'IQ_NTM']

        for mnemonic, caption in desired_order:
            properties = {}
            for identifier in identifiers:

                if mnemonic in gdshe_mnemonics:
                    function = Functions.GDSHE
                    for period_type in period_types:
                        mnemonics_payload.append({"identifier":identifier,
                                                 "mnemonic": mnemonic,
                                                  "function": function,
                                                  "properties": {"periodType": period_type}
                                                  })
                else:
                    payload = {
                        "identifier":identifier,
                        "mnemonic": mnemonic,
                        "function": function,
                        "properties": properties
                    }
                    mnemonics_payload.append(payload)
        return mnemonics_payload
