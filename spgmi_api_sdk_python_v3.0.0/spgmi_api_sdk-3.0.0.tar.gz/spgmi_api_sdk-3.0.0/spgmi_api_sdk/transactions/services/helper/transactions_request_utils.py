import logging

from spgmi_api_sdk.transactions.constants.functions_constants import Functions
from spgmi_api_sdk.transactions.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class TransactionDataRequestUtils:
    @staticmethod
    def generate_trans_request_payload(identifiers, function=Functions.GDSP):
        mnemonics_payload = []
        desired_order = [
            ("IQ_TR_TRANSACTION_TYPE", "Transaction type"),
            ("IQ_TR_DEAL_RESOLUTION", "Transaction description"),
            ("IQ_TR_TOTALVALUE", "Transaction Value"),
            ("IQ_TR_ANN_DATE", "Transaction announcement date"),
            ("IQ_TR_CLOSED_DATE", "Transaction complete date")
        ]

        for mnemonic, caption in desired_order:
            for transid_identifier in identifiers:
                properties = {}
                payload = {
                    "identifier":transid_identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                mnemonics_payload.append(payload)

        return mnemonics_payload

    @staticmethod
    def generate_trans_list_request_payload(identifiers, function=Functions.GDSP):
        transaction_identifier_payload = []
        desired_order = [
            ("IQ_TRANSACTION_LIST", "Transaction list")
        ]

        for mnemonic, caption in desired_order:
            for identifier in identifiers:
                properties = {}
                if mnemonic == "IQ_TRANSACTION_LIST":
                    properties["startRank"] = "1"
                    properties["endRank"] = "5"
                    function = Functions.GDSHE
                payload = {
                    "identifier": identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                if payload.get("mnemonic") == "IQ_TRANSACTION_LIST":
                    transaction_identifier_payload.append(payload)

        return transaction_identifier_payload
