class ErrorMessages:
    _IDENTIFIERS_FORMAT_ERROR = "The 'identifiers' parameter must be a list with at least one identifier."
    _IDENTIFIERS_SIZE = 10
    _IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR = f"The 'identifiers' list should not contain more than {_IDENTIFIERS_SIZE} items."

    @property
    def identifiers_format_error(self):
        return self._IDENTIFIERS_FORMAT_ERROR

    @property
    def identifiers_size(self):
        return self._IDENTIFIERS_SIZE

    @property
    def identifiers_list_size_exceeded_error(self):
        return self._IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR



