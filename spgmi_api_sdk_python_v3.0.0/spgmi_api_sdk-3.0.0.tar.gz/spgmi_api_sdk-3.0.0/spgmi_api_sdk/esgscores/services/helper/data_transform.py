import traceback
import pandas as pd
import logging
from spgmi_api_sdk.esgscores.constants.data_config import DataConfig
from spgmi_api_sdk.esgscores.constants.error_messages import ErrorMessages

logger = logging.getLogger(__name__)
class DataFormat:

    def __init__(self):
        self.data_config = DataConfig()
        self.error_messages = ErrorMessages()



    def aggregate_response(self,results):

        data2_dict = {item['Identifier']: item['Environmental Impact Ratio'] for item in
                      results["trucost_env_response"]}
        data3_dict = {item['Identifier']: item['Paris Alignment Current Alignment'] for item in
                      results["paris_alignment"]}
        data4_dict = {item['Identifier']: item['Carbon Earnings at Risk Unpriced Carbon Cost ($)'] for item in
                      results["trucost_cear"]}
        data5_dict = {item['Identifier']: item['Physical Risk Composite Score 2030'] for item in
                      results["physical_risk"]}

        merged_data = []
        for item in results["esg_response"]:
            identifier = item['Identifier']
            if identifier in data2_dict:
                item['Environmental Impact Ratio'] = data2_dict[identifier]
            else:
                item['Environmental Impact Ratio'] = 'Data Unavailable'
            if identifier in data3_dict:
                item['Paris Alignment Current Alignment'] = data3_dict[identifier]
            else:
                item['Paris Alignment Current Alignment'] = 'Data Unavailable'
            if identifier in data4_dict:
                item['Carbon Earnings at Risk Unpriced Carbon Cost ($)'] = data4_dict[identifier]
            else:
                item['Carbon Earnings at Risk Unpriced Carbon Cost ($)'] = 'Data Unavailable'
            if identifier in data5_dict:
                item['Physical Risk Composite Score 2030'] = data5_dict[identifier]
            else:
                item['Physical Risk Composite Score 2030'] = 'Data Unavailable'

            merged_data.append(item)

        return merged_data


    def _format_response(self, response_json, assessmentYear):
        response_json = response_json[0]
        values = []
        processed_identifiers = set()
        try:
            if response_json:
                results = response_json.get("results")
                for result in results:
                    institution_id = result.get('institutionId')
                    result_assessment_year = result.get('assessmentYear')
                    if assessmentYear is None and institution_id in processed_identifiers:
                        continue

                    temp = {
                        'Identifier': institution_id,
                        'ESG Score': result.get('esgScore'),
                        'ENV Score': result.get('envScore'),
                        'Social Score':result.get('socialScore'),
                        'GE Score':result.get('geScore'),
                        'Methodology Year': result_assessment_year
                    }

                    # Initialize all expected criteria with "Data Unavailable"
                    expected_criteria = self.data_config.get_criteria_name()
                    for criteria_name in expected_criteria:
                        temp[criteria_name] = "Data Unavailable"

                    # Fill in available criteria scores
                    criterias = result.get('criteria', [])
                    for criteria in criterias:
                        criteria_name = criteria.get('criteriaName')
                        if criteria_name in expected_criteria:
                            temp[criteria_name] = criteria.get('criteriaScore')

                    values.append(temp)
                    processed_identifiers.add(institution_id)
            else:
                values = response_json

        except Exception as e:
            raise
        return values


    def _format_response_trucost_env(self,response_json):
        response_json = response_json[0]
        processed_identifiers = set()
        values = []
        try:
            if response_json:
                results = response_json.get("results")
                for result in results:
                    institution_id = result.get('institutionId')
                    if institution_id in processed_identifiers:
                        continue
                    temp = {}
                    institution_id = result.get('institutionId')
                    temp['Identifier'] = institution_id
                    temp['Environmental Impact Ratio'] = result.get('tcIRDrtNIndrtCost')
                    values.append(temp)
                    processed_identifiers.add(institution_id)
            else:
                values = response_json
        except Exception as e:
            raise
        return values


    def _format_response_trucost_cear(self,response_json):
        response_json = response_json[0]
        processed_identifiers = set()
        values = []
        try:
            if response_json:
                results = response_json.get("results")
                for result in results:
                    institution_id = result.get('institutionId')
                    if institution_id in processed_identifiers:
                        continue
                    temp = {}
                    institution_id = result.get('institutionId')
                    temp['Identifier'] = institution_id
                    temp['Carbon Earnings at Risk Unpriced Carbon Cost ($)'] = result.get('tcABSUnpricedCarbonTotal')
                    values.append(temp)
                    processed_identifiers.add(institution_id)
            else:
                values = response_json

        except Exception as e:
            raise
        return values


    def _format_response_paris_alignment(self,response_json):
        response_json = response_json[0]
        processed_identifiers = set()
        values = []
        try:
            if response_json:
                results = response_json.get("results")
                for result in results:
                    institution_id = result.get('institutionId')
                    if institution_id in processed_identifiers:
                        continue
                    temp = {}
                    institution_id = result.get('institutionId')
                    temp['Identifier'] = institution_id
                    temp['Paris Alignment Current Alignment'] = self.data_config.get_current_alignment_mapping()[
                        result.get('currentAlignment')]
                    values.append(temp)
                    processed_identifiers.add(institution_id)
            else:
                values = response_json

        except Exception as e:
            raise
        return values

    def _format_response_physical_risk(self, response_json):
        response_json = response_json[0]
        processed_identifiers = set()
        values = []
        try:
            if response_json:
                results = response_json.get("results")
                for result in results:
                    institution_id = result.get('institutionId')
                    if institution_id in processed_identifiers:
                        continue
                    temp = {}
                    institution_id = result.get('institutionId')
                    temp['Identifier'] = institution_id
                    temp['Physical Risk Composite Score 2030'] = result.get('compositeScore')
                    values.append(temp)
                    processed_identifiers.add(institution_id)
            else:
                values = response_json

        except Exception as e:
            raise
        return values

    def convert_to_dataframe(self, data, identifier_mapping):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        try:
            df = pd.DataFrame(data) if data else pd.DataFrame(
                columns=['Identifier', 'Methodology Year', 'ESG Score', 'ENV Score','Social Score','GE Score',
                         'Climate Strategy', 'Emissions',
                         'Environmental Policy & Management Systems',
                         'Resource Efficiency and Circularity', 'Waste', 'Water',
                         'Customer Relationship Management', 'Human Capital Development',
                         'Human Rights', 'Labor Practice Indicators',
                         'Occupational Health & Safety', 'Privacy Protection',
                         'Talent Attraction & Retention', 'Governance & Economic Score',
                         'Business Ethics', 'Corporate Governance', 'Information Security',
                         'Cybersecurity & System Availability', 'Innovation Management',
                         'Materiality', 'Policy Influence', 'Risk & Crisis Management',
                         'Tax Strategy', 'Transparency & Reporting',
                         'Environmental Impact Ratio',
                         'Paris Alignment Current Alignment',
                         'Carbon Earnings at Risk Unpriced Carbon Cost ($)',
                         'Physical Risk Composite Score 2030'])

            if not df.empty:
                df['Identifier'] = 'SNL' + df['Identifier'].astype(str)
                df['Identifier'] = df['Identifier'].replace({v: k for k, v in identifier_mapping.items()})
            all_identifiers = set(identifier_mapping.keys())
            existing_identifiers = set(df['Identifier'])
            missing_identifiers = all_identifiers - existing_identifiers

            missing_rows = []
            for identifier in missing_identifiers:
                row = {'Identifier': identifier}
                error_message = identifier_mapping[identifier]
                if error_message.isdigit():
                    error_message = "Data Unavailable"
                elif identifier.lower().startswith("snl"):
                    error_message = "Not Applicable"
                for col in df.columns:
                    if col != 'Identifier':
                        row[col] = error_message
                missing_rows.append(row)

            df = pd.concat([df, pd.DataFrame(missing_rows)], ignore_index=True)
            df.index = range(1, len(df) + 1)
            column_name = 'Carbon Earnings at Risk Unpriced Carbon Cost ($)'
            if column_name in df.columns:
                df[column_name] = df[column_name].apply(lambda x: '{:.8f}'.format(x) if isinstance(x, float) else x)

            response_color = 'lightyellow'
            identifier_color = 'lightblue'
            columns_order = ['Identifier'] +['Methodology Year'] + [col for col in df.columns if
                                col not in ['Identifier', 'Methodology Year']]

            df = df[columns_order]


            '''header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', identifier_color), ('text-align', 'center'),
                           ('border', '1px solid black')]}
            ]

            # Add styles for all columns
            for i, col in enumerate(columns_order, start=1):  # Start at 1 for index alignment
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            #raise e
            traceback.print_exc()
            #return None
            raise e

