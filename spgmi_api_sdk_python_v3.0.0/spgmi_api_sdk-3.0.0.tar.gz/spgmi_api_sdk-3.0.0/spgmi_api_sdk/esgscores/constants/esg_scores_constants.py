class EsgScoresConstants:
    criteria_name = [
            "Climate Strategy",
            "Emissions",
            "Environmental Policy & Management Systems",
            "Resource Efficiency and Circularity",
            "Waste",
            "Water",
            "Customer Relationship Management",
            "Human Capital Development",
            "Human Rights",
            "Labor Practice Indicators",
            "Occupational Health & Safety",
            "Privacy Protection",
            "Talent Attraction & Retention",
            "Governance & Economic Score",
            "Business Ethics",
            "Corporate Governance",
            "Information Security",
            "Cybersecurity & System Availability",
            "Innovation Management",
            "Materiality",
            "Policy Influence",
            "Risk & Crisis Management",
            "Tax Strategy",
            "Transparency & Reporting"
        ]
    current_alignment_mapping = {
            0: "<1.5°C",
            1: "<1.75°C",
            2: "1.5-2°C",
            3: "1.75-2°C",
            4: "2-2.7°C",
            5: ">2.7°C",
            6: "2-3°C",
            7: "3-4°C",
            8: "4-5°C",
            9: ">5°C"
        }

    identifier_conversion_mnemonic = "BECRS_ENTITY_BASE"

    identifier_conversion_function = "GDSPV"