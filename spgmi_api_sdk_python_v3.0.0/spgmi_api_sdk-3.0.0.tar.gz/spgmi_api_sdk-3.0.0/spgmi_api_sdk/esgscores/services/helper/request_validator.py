from spgmi_api_sdk.esgscores.constants.error_messages import ErrorMessages
import logging

logger = logging.getLogger(__name__)


class RequestValidator:
    def __init__(self):
        self.error_messages = ErrorMessages()

    def validate_request(self, identifiers,assessment_year=None):
        error_messages = []

        # Validate that identifiers is a list with at least one identifier
        if not isinstance(identifiers, list) or not identifiers or not all(
                isinstance(identifier, str) for identifier in identifiers):
            error_message = self.error_messages.identifiers_format_error
            logger.error(error_message)
            error_messages.append(error_message)


        # Validate the size of the identifiers list
        identifiers_size = 1
        if len(identifiers) > identifiers_size:
            error_message = self.error_messages.identifiers_list_size_exceeded_error
            logger.error(error_message)
            error_messages.append(error_message)






        # Validate that identifier_type is a string (if provided)
        if assessment_year is not None and not isinstance(assessment_year, str):
            error_message = "assessment_year must be a string."
            logger.error(error_message)
            error_messages.append(error_message)

        return error_messages

