from abc import ABC, abstractmethod
import pandas as pd


class TransactionsServicesInterface(ABC):

    @abstractmethod
    def get_transactions(self, token, identifiers, proxy=None):
        pass
