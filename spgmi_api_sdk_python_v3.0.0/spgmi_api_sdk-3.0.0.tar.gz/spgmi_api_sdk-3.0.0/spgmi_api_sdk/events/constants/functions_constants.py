class FunctionConstants:


    _events_id_function = "GDSHE"
    _events_function = "GDSP"
