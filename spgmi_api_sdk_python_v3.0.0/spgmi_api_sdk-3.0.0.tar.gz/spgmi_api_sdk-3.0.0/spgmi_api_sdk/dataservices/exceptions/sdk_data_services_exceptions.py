from requests.exceptions import HTTPError

class APIRequestException(Exception):
    def __init__(self, status_code, message="API request error occurred"):
        self.status_code = status_code
        self.message = f"API request failed with status {status_code}: {message}"
        super().__init__(self.message)

class DataRequestError(Exception):
    def __init__(self, status_code, message):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code


class DNSResolutionError(Exception):
    def __init__(self, host, original_exception):
        super().__init__(f"Failed to resolve DNS for host '{host}': {original_exception}")

class APIErrorException(Exception):
    """Custom exception for API errors with an optional status code."""
    def __init__(self, message, status_code=None):
        self.message = message
        self.status_code = status_code
        super().__init__(f"API Error {status_code}: {message}" if status_code else message)

