from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput

from spgmi_api_sdk.dataservices.model.sdk_data_request import SDKDataRequest

from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
import traceback
from urllib.error import HTTPError
import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.stockprices.constants.data_config import DataConfig
from spgmi_api_sdk.stockprices.services.helper.data_transform import DataFormat
from spgmi_api_sdk.stockprices.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.stockprices.services.sdk_stockprices_services_interface import StockPricesServicesInterface
from datetime import datetime
from spgmi_api_sdk.stockprices.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)
class SDKStockPricesServices(StockPricesServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_director = RequestDirector()
        self.data_format = DataFormat()
        self.request_validator = RequestValidator()
        self._default_properties = DefaultProperties()
        self.data_config = DataConfig()

    def get_stock_price(self, token, identifiers, proxy=None):
        function = self.data_config.get_stock_prices_function()
        mnemonics = self.data_config.get_stock_prices_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        current_date = datetime.now()
        f_current_date = current_date.strftime('%m/%d/%Y')
        one_year_ago = current_date.replace(year=current_date.year - 1)
        f_one_year_ago = one_year_ago.strftime('%m/%d/%Y')

        properties = {"startDate": f_one_year_ago,"endDate": f_current_date}

        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())
            sdk_data_request = self.__create_sdk_data_request(identifiers_converted, function, properties,
                                                              mnemonics=mnemonics)
            sdk_input_request = self.__create_sdk_data_input(token, proxy, sdk_data_request)

            final_output = self.data_services._invoke_data_service(sdk_input_request)
            df = DataFormat.convert_to_dataframe_gdshe(final_output,identifier_mapping=identifier_mapping, caption=
                                                       self.data_config.get_stock_prices_mnemonics_caption())

            return df
        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e

    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input


