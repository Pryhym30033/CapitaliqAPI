from abc import ABC, abstractmethod
import pandas as pd


class RiskGaugeScoreServicesInterface(ABC):

    @abstractmethod
    def get_risk_gauge_score (self, token, identifiers, scoring_date, proxy=None):
        pass
