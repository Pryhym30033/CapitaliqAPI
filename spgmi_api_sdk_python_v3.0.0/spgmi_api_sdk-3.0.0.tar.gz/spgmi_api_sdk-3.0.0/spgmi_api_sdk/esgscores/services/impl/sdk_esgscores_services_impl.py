import threading
import time

from spgmi_api_sdk.dataservices.exceptions.sdk_data_services_exceptions import APIRequestException
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices

from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
from spgmi_api_sdk.esgscores.constants.data_config import DataConfig
from spgmi_api_sdk.esgscores.services.esgscores_services_interface import EsgScoresServicesInterface
from spgmi_api_sdk.esgscores.services.helper.data_transform import DataFormat
import logging.config
import traceback
from urllib.error import HTTPError

from spgmi_api_sdk.esgscores.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.esgscores.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)
class SDKEsgScoresServices(EsgScoresServicesInterface):
    def __init__(self):
        self.request_director = RequestDirector()
        self._default_properties = DefaultProperties()
        self.data_format = DataFormat()
        self.data_config = DataConfig()
        self.request_validator = RequestValidator()
        self.data_services = SDKDataServices()



    def get_esg_scores(self, token, identifiers,assessment_year=None, proxy=None):
        error_messages = self.request_validator.validate_request(identifiers,assessment_year)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_all_ids_to_snl(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())
            identifiers_converted_wo_SNL = [identifier.upper().removeprefix("SNL") for identifier in identifiers_converted]

            valid_identifiers = ["SNL"+identifier for identifier in identifiers_converted_wo_SNL if
                                 identifier.isdigit()]
            if not valid_identifiers:
                return self.data_format.convert_to_dataframe([], identifier_mapping)


            results = {}

            def run_esg_response(valid_identifiers, token, proxy):
                try:
                    results['esg_response'] = self._process_api_request(valid_identifiers, token, assessment_year,proxy)
                except Exception as e:
                    results['esg_response'] = f"ERROR: {str(e)}"

            def run_trucost_env_response(valid_identifiers, token, proxy):
                try:
                    results['trucost_env_response'] = self._process_trucost_env_request(valid_identifiers, token, proxy)
                except Exception as e:
                    results['trucost_env_response'] = f"ERROR: {str(e)}"

            def run_paris_alignment(valid_identifiers, token, proxy):
                try:
                    results['paris_alignment'] = self._process_paris_alignment_request(valid_identifiers, token, proxy)
                except Exception as e:
                    results['paris_alignment'] = f"ERROR: {str(e)}"

            def run_trucost_cear(valid_identifiers, token, proxy):
                try:
                    results['trucost_cear'] = self._process_trucost_cear_request(valid_identifiers, token, proxy)
                except Exception as e:
                    results['trucost_cear'] = f"ERROR: {str(e)}"

            def run_physical_risk(valid_identifiers, token, proxy):
                try:
                    results['physical_risk'] = self._process_physical_risk_request(valid_identifiers, token, proxy)
                except Exception as e:
                    results['physical_risk'] = f"ERROR: {str(e)}"

            # Create threads with arguments
            threads = [
                threading.Thread(target=run_esg_response, args=(valid_identifiers, token, proxy)),
                threading.Thread(target=run_trucost_env_response, args=(valid_identifiers, token, proxy)),
                threading.Thread(target=run_paris_alignment, args=(valid_identifiers, token, proxy)),
                threading.Thread(target=run_trucost_cear, args=(valid_identifiers, token, proxy)),
                threading.Thread(target=run_physical_risk, args=(valid_identifiers, token, proxy))
            ]

            # Start threads
            for thread in threads:
                thread.start()

            # Wait for all threads to complete
            for thread in threads:
                thread.join()

            for key, value in results.items():
                if isinstance(value, str) and value.startswith("ERROR"):
                    raise APIRequestException(value)

            merged_data = self.data_format.aggregate_response(results)

            df = self.data_format.convert_to_dataframe(merged_data,identifier_mapping)


            return df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e



    def _process_api_request(self, identifiers, token,assessment_year, sdk_proxy):
        try:
            institution_ids = []
            for identifier in identifiers:
                institution_ids.append(identifier[3:])
            payload = {
                "institutionId":
                    institution_ids,
                "csaScoreTypeName": "Modeled"
            }
            if assessment_year:
                payload["assessmentYear"] = [assessment_year]

            return self.data_format._format_response(
                RequestDirector._send_sdk_request(self.request_director, bearer_token=token, sdk_proxy=sdk_proxy,
                                                  retry=True, batch=[payload],
                                                  url=self._default_properties.ESG_ENDPOINT_URL), assessment_year)
        except Exception as e:
            raise e

    def _process_trucost_env_request(self, identifiers, token, sdk_proxy):
        try:
            institution_ids = []
            for identifier in identifiers:
                institution_ids.append(identifier[3:])
            payload = {
                "institutionId": institution_ids,
                "page": 1,
                "fields": ["tcIRDrtNIndrtCost"],
                "pageSize":100
            }
            return self.data_format._format_response_trucost_env(
                RequestDirector._send_sdk_request(self.request_director, bearer_token=token, sdk_proxy=sdk_proxy,
                                                  retry=True, batch=[payload],
                                                  url=self._default_properties.TRUCOST_ENV_ENDPOINT_URL))

        except Exception as e:
            raise e

    def _process_trucost_cear_request(self, identifiers, token, sdk_proxy):
        try:
            institution_ids = []
            for identifier in identifiers:
                institution_ids.append(identifier[3:])
            payload = {
                "fields": [
                    "tcABSUnpricedCarbonTotal"
                ],
                "institutionId":
                    institution_ids,
                "scenarioLevel": [
                    "Medium"
                ],
                "forecastYear": [
                    2030
                ],
                "isLatest": "Yes",
                "page": 1
            }
            return self.data_format._format_response_trucost_cear(
                RequestDirector._send_sdk_request(self.request_director, bearer_token=token, sdk_proxy=sdk_proxy,
                                                  retry=True, batch=[payload],
                                                  url=self._default_properties.TRUCOST_CEAR_URL))

        except Exception as e:
            raise e

    def _process_paris_alignment_request(self, identifiers,token, sdk_proxy):
        try:
            institution_ids = []
            for identifier in identifiers:
                institution_ids.append(identifier[3:])
            payload = {
                "fields": [
                    "currentAlignment"
                ],
                "institutionId":
                    institution_ids,
                "isLatest": "Yes"
            }
            return self.data_format._format_response_paris_alignment(
                RequestDirector._send_sdk_request(self.request_director, bearer_token=token, sdk_proxy=sdk_proxy,
                                                  retry=True, batch=[payload],
                                                  url=self._default_properties.PARIS_ALIGNMENT_URL))
        except Exception as e:
            raise e

    def _process_physical_risk_request(self, identifiers, token, sdk_proxy):
        try:
            institution_ids = []
            for identifier in identifiers:
                institution_ids.append(identifier[3:])
            payload = {
                "fields": [
                    "compositeScore"
                ],
                "institutionId":
                    institution_ids,
                "scenarioLevel": [
                    "Medium"
                ],
                "forecastYear": [
                    2030
                ],
                "isLatest": "Yes"
            }
            return self.data_format._format_response_physical_risk(
                RequestDirector._send_sdk_request(self.request_director, bearer_token=token, sdk_proxy=sdk_proxy,
                                                  retry=True, batch=[payload],
                                                  url=self._default_properties.PHYSICAL_RISK_URL))
        except Exception as e:
            raise e






