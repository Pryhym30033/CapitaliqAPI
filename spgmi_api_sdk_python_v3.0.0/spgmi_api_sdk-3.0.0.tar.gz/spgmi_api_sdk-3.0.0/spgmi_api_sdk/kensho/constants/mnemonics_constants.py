class MnemonicConstants:
    _company_name_to_id_mnemonics = [
        "KL_COMPANY_ID_NAME_QUICK_MATCH"
    ]
    _ticker_id_mnemonics = [
        "IQ_COMPANY_TICKER"
    ]
    identifier_conversion_mnemonic = "BECRS_ENTITY_BASE"
