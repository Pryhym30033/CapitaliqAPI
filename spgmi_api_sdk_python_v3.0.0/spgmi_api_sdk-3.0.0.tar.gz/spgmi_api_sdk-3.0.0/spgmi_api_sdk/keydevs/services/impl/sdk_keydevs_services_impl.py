from spgmi_api_sdk.dataservices.model.sdk_data_input import SDKDataInput
from spgmi_api_sdk.dataservices.model.sdk_data_request import SDKDataRequest
from spgmi_api_sdk.dataservices.util.default_properties import DefaultProperties
from spgmi_api_sdk.dataservices.services.helper.request_director import RequestDirector
import traceback
from urllib.error import HTTPError
import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.keydevs.constants.data_config import DataConfig
from spgmi_api_sdk.keydevs.services.keydevs_services_interface import KeyDevsServicesInterface
from spgmi_api_sdk.keydevs.services.helper.data_transform import DataFormat
from spgmi_api_sdk.keydevs.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.keydevs.util.logging_utils import LoggingUtils
import pandas as pd
from datetime import datetime, date, timedelta
LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)
class SDKKeyDevsServices(KeyDevsServicesInterface):
    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_director = RequestDirector()
        self.data_format = DataFormat()
        self.request_validator = RequestValidator()
        self._default_properties = DefaultProperties()
        self.data_config = DataConfig()


    def get_key_devs(self, token, identifiers, proxy=None):
        key_dev_id_function = self.data_config.get_keydev_id_function()
        key_dev_id_mnemonics = self.data_config.get_keydev_id_mnemonics()
        key_dev_function = self.data_config.get_keydev_function()
        key_dev_mnemonics = self.data_config.get_keydev_mnemonics()
        error_messages = self.request_validator.validate_request(identifiers)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            sdk_data_request1 = self.__create_sdk_data_request(identifiers=identifiers_converted, function=key_dev_id_function, mnemonics= key_dev_id_mnemonics)
            sdk_input_request1 = self.__create_sdk_data_input(token, proxy, sdk_data_request1)
            final_output1 = self.data_services._invoke_data_service(sdk_input_request1)
            df1 = self.data_format._convert_to_dataframe_pitv(final_output1)

            keydev_identifiers = df1["IQ_KEY_DEV_ID"].tolist()

            sdk_data_request2 = self.__create_sdk_data_request(keydev_identifiers, key_dev_function,
                                                               mnemonics=key_dev_mnemonics)
            sdk_input_request2 = self.__create_sdk_data_input(token, proxy, sdk_data_request2)
            final_output2 = self.data_services._invoke_data_service(sdk_input_request2)

            df2 = self.data_format._convert_to_dataframe_pit(final_output2)

            merged_df = self.data_format._merge_response(df1, df2,identifier_mapping,caption=
                                                       self.data_config.get_keydev_data_mnemonics_caption())

            return merged_df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e


    def __create_sdk_data_request(self, identifiers, function, properties={}, mnemonics=None):
        request = SDKDataRequest(
            function=function,
            properties=properties,
            identifiers=identifiers,
            mnemonics=mnemonics
        )
        return request

    def __create_sdk_data_input(self, token, proxy, sdk_data_request):
        data_input = SDKDataInput(
            sdk_proxy=proxy,
            bearer_token=token,
            data_requests=sdk_data_request
        )
        return data_input