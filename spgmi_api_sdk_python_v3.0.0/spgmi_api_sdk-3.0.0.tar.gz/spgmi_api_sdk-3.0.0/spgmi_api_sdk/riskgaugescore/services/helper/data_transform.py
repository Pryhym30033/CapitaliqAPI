import traceback
from datetime import datetime

import pandas as pd

import logging

logger = logging.getLogger(__name__)
class DataFormat:

    @staticmethod
    def getriskgaugescores_response_to_dataframe(response, identifier_mapping, scoring_date):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)
        try:
            user_identifiers = list(identifier_mapping.keys())

            data = {'Identifier': user_identifiers}

            scoring_date = scoring_date if scoring_date else datetime.now().strftime("%m/%d/%Y")
            data['Scoring Date'] = [scoring_date] * len(user_identifiers)


            for mnemonic, item in response.items():
                data[f"{mnemonic}"] = [
                    next((value[0] for value in item.get(identifier_mapping.get(identifier, identifier), [])), None)
                    for identifier in user_identifiers
                ]

            df = pd.DataFrame(data)
            df.index = df.index + 1
            desired_order = [
                ("IQ_RG_STANDALONE_CREDIT_SCORE", "RiskGauge - Standalone Score"),
                ("IQ_RG_STANDALONE_ONE_TO_HUNDRED", "RiskGauge - Standalone Score 1 - 100"),
                ("IQ_RG_SOV_CREDIT_SCORE", "RiskGauge - Sovereign Capped Score"),
                ("IQ_RG_SOV_ONE_TO_HUNDRED", "RiskGauge - Sovereign Capped Score 1 - 100"),
                ("IQ_RG_PG_CREDIT_SCORE", "RiskGauge - Sovereign Capped Parental & Govt. Support Score"),
                ("IQ_RG_PG_ONE_TO_HUNDRED", "RiskGauge - Sovereign Capped Parental & Govt. Support Score 1 - 100")
            ]
            for mnemonic, caption in desired_order:
                if mnemonic in df.columns and not df[mnemonic].isnull().all():
                    df.rename(columns={mnemonic: f"{mnemonic} ({caption})"}, inplace=True)

            '''identifier_color = 'lightblue'
            mnemonic_color = 'lightyellow'

            header_styles = [
                {'selector': f'th.col0', 'props': [('background-color', identifier_color), ('text-align', 'center'),
                                                   ('border', '1px solid black')]},
            ]

            for i in range(1, len(df.columns)):
                header_styles.append({'selector': f'th.col{i}', 'props': [('background-color', mnemonic_color),
                                                                          ('text-align', 'center'),
                                                                          ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                    {'selector': 'th', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df

        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e