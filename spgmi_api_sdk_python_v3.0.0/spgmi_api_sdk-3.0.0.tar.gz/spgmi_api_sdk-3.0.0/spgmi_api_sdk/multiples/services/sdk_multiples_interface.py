from abc import ABC, abstractmethod
import pandas as pd


class MultiplesServicesInterface(ABC):

    @abstractmethod
    def get_multiples (self, token, identifiers, proxy=None):
        pass
