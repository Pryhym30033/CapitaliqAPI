import pandas as pd
import traceback
import logging

from spgmi_api_sdk.dataservices.services.helper.data_transform_util import DataTransformUtil

logger = logging.getLogger(__name__)

class DataFormat:





    def convert_to_dataframe_gdshe(data, properties={}, identifier_mapping={}, caption={}):
        meta_data_tag = 'Date'
        if meta_data_tag == 'asOfDate' and 'asOfDate' in properties:
            del properties['asOfDate']
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        flattened_data = {}
        all_subkeys = set()

        try:
            for main_key, sub_dict in data.items():
                for sub_key, value_list in sub_dict.items():
                    all_subkeys.add(sub_key)
                    if sub_key not in flattened_data:
                        flattened_data[sub_key] = {}
                    for values in value_list:
                        if main_key not in flattened_data[sub_key]:
                            flattened_data[sub_key][main_key] = []
                        flattened_data[sub_key][main_key].append(values)

            for sub_key in all_subkeys:
                for main_key in data.keys():
                    if main_key not in flattened_data[sub_key]:
                        flattened_data[sub_key][main_key] = [['', '']]

            rows = []
            for sub_key, main_key_data in flattened_data.items():

                max_length = max(len(values) for values in main_key_data.values())

                for i in range(max_length):
                    row = {'Identifier': sub_key}
                    date = ''
                    for main_key in data.keys():
                        values = main_key_data[main_key]
                        if i < len(values):
                            row[main_key] = values[i][0]

                            if len(values[i]) > 1 and values[i][1]:
                                date = values[i][1]

                        else:
                            row[main_key] = ''

                    row[meta_data_tag] = date
                    for prop_key, prop_value in properties.items():
                        row[prop_key] = prop_value
                    rows.append(row)

            df = pd.DataFrame(rows)
            has_period_date = 'IQ_PERIODDATE' in df.columns
            if caption:
                new_columns = {}
                for col in df.columns:
                    if col in caption:
                        new_columns[col] = f"{col} ({caption[col]})"
                    else:
                        new_columns[col] = col
                # Rename the columns
                df.rename(columns=new_columns, inplace=True)
                identifier_color = 'lightblue'
            else:
                identifier_color = 'lightyellow'

            if identifier_mapping:
                df= DataTransformUtil.process_identifiers_in_dataframe(df,identifier_mapping)
            df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y', errors='coerce')

            df = df.sort_values(by=['Identifier', 'Date'], ascending=[True, True], na_position='last')

            df['Date'] = df['Date'].dt.strftime('%m/%d/%Y').fillna('')
            df = df.reset_index(drop=True)

            property_columns = list(properties.keys())
            response_columns = [col for col in df.columns if
                                col not in ['Identifier', meta_data_tag] + property_columns]

            columns_order = ['Identifier'] + [meta_data_tag] + response_columns + property_columns
            df = df[columns_order]
            if has_period_date and meta_data_tag in df.columns:
                del df[meta_data_tag]
            df.index = range(1, len(df) + 1)

            '''response_color = 'lightyellow'
            property_color = 'lightblue'

            header_styles = [
                {'selector': 'th.col0',
                 'props': [('background-color', identifier_color), ('text-align', 'center'),
                           ('border', '1px solid black')
                           ]},
                {'selector': 'th.col1',
                 'props': [('background-color', response_color), ('text-align', 'center'),
                           ('border', '1px solid black')]}
            ]

            for i, col in enumerate(response_columns, start=2):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', response_color), ('text-align', 'center'),
                                                ('border', '1px solid black')]})

            for i, col in enumerate(property_columns, start=2 + len(response_columns)):
                header_styles.append({'selector': f'th.col{i}',
                                      'props': [('background-color', property_color), ('text-align', 'center'),
                                                ('border', '1px solid black')]})

            df_styled = df.style.set_table_styles(
                header_styles + [
                    {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]}
                ]
            ).set_properties(**{'text-align': 'center'})

            return df_styled'''
            return df
        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            traceback.print_exc()
            raise e

