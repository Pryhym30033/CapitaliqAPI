from spgmi_api_sdk.kensho.constants.mnemonics_constants import MnemonicConstants
from spgmi_api_sdk.kensho.constants.functions_constants import FunctionConstants


class DataConfig:
    def get_company_name_to_id_mnemonics(self):
        return MnemonicConstants._company_name_to_id_mnemonics


    def get_company_name_to_id_function(self):
        return FunctionConstants._company_name_to_id_function

    def get_ticker_id_function(self):
        return FunctionConstants._ticker_id_function

    def get_ticker_id_mnemonics(self):
        return MnemonicConstants._ticker_id_mnemonics

    def get_identifier_conversion_mnemonic(self):
        return MnemonicConstants.identifier_conversion_mnemonic

    def get_identifier_conversion_function(self):
        return FunctionConstants.identifier_conversion_function



