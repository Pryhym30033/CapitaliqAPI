import functools
import inspect
import logging

from spgmi_api_sdk.dataservices.exceptions.sdk_data_services_exceptions import APIRequestException
from spgmi_api_sdk.ciq.util.logging_utils import LoggingUtils
LoggingUtils.load_logging_config()
logger = logging.getLogger(__name__)

def retry_on_unauthorized(func):
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        max_retries = 2
        attempt = 0

        func_signature = inspect.signature(func)
        param_names = list(func_signature.parameters.keys())

        token_provided_as_kwarg = "token" in kwargs

        token_provided_as_positional = False
        if 'token' in param_names:
            token_index = param_names.index('token') - 1
            if token_index < len(args):
                token_provided_as_positional = True

        if token_provided_as_kwarg or token_provided_as_positional:
            return func(self, *args, **kwargs)

        while attempt < max_retries:
            try:
                return func(self, *args, **kwargs)
            except APIRequestException as e:
                if "401 Unauthorized" in str(e) or "Token is invalid or has expired" in str(e):
                    if attempt < max_retries - 1:
                        logger.info(f"Attempt {attempt + 1}: Token expired or unauthorized. Retrying...")
                        attempt += 1
                    else:
                        logger.error("Max retries reached. Raising exception.")
                        raise
                else:
                    raise

    return wrapper
