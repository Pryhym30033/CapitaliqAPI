from spgmi_api_sdk.authentication.constants.token_constants import TokenServiceConstants


class InvalidCredentialsError(Exception):
        def __init__(self, message=TokenServiceConstants.MISSING_CREDENTIALS, status_code=400):
            super().__init__(f"HTTP {status_code}: {message}")
            self.status_code = status_code



class TokenRequestError(Exception):
    def __init__(self, status_code, message):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code


class DNSResolutionError(Exception):
    def __init__(self, host, original_exception):
        super().__init__(f"Failed to resolve DNS for host '{host}': {original_exception}")


class PropertyNotFoundError(Exception):
    pass
