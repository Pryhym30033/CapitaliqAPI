from spgmi_api_sdk.events.constants.functions_constants import FunctionConstants
from spgmi_api_sdk.events.constants.mnemonics_constants import MnemonicConstants


class DataConfig:


    def get_event_mnemonics(self):
        return MnemonicConstants._events_mnemonics

    def get_events_data_mnemonics_caption(self):
        return MnemonicConstants._events_mnemonics_captions

    def get_events_id_function(self):
        return FunctionConstants._events_id_function

    def get_events_id_mnemonics(self):
        return MnemonicConstants._events_id_mnemonics

    def get_events_function(self):
        return FunctionConstants._events_function





