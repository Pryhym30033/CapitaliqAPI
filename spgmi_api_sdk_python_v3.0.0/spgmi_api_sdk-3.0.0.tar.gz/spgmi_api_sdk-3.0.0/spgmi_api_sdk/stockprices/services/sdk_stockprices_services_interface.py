from abc import ABC, abstractmethod
import pandas as pd

class StockPricesServicesInterface(ABC):

    @abstractmethod
    def get_stock_price(self, token, identifiers,  proxy=None) -> pd.DataFrame:
        pass
