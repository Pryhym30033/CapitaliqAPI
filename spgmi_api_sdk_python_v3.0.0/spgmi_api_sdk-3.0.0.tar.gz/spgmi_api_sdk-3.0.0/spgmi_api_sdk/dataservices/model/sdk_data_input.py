from spgmi_api_sdk.dataservices.model.sdk_data_input_base import SDKDataInputBase
from spgmi_api_sdk.dataservices.model.sdk_data_request import SDKDataRequest


class SDKDataInput(SDKDataInputBase):
    def __init__(self, bearer_token: str = None, sdk_proxy=None, data_requests: SDKDataRequest = None):
        super().__init__(bearer_token, sdk_proxy)
        self._data_requests = data_requests

    @property
    def data_requests(self):
        return self._data_requests

    @data_requests.setter
    def data_requests(self, data_requests):
        self._data_requests = data_requests

    @property
    def sdk_proxy(self):
        return self._sdk_proxy

    @sdk_proxy.setter
    def sdk_proxy(self, sdk_proxy):
        from spgmi_api_sdk.ciq.services.sdk_ciq_data_services import SDKProxy

        if sdk_proxy is not None and not isinstance(sdk_proxy, SDKProxy):
            raise ValueError("sdk_proxy must be an instance of SDKProxy or None")
        self._sdk_proxy = sdk_proxy

    def __str__(self):
        return f"Bearer Token: {self.bearer_token}, Data Requests: {self.data_requests}"
