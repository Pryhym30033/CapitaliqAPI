import logging

from spgmi_api_sdk.riskgaugescore.constants.functions_constants import Functions
from spgmi_api_sdk.riskgaugescore.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class MultiplesRequestUtils:
    @staticmethod
    def generate_multiples_request_payload(identifiers, function=Functions.GDSP):
        mnemonics_payload = []
        desired_order = [
            ("IQ_PE_EXCL", "P/LTM EPS (x)"),
            ("IQ_PE_EXCL_FWD_CIQ", "P/NTM EPS (x)"),
            ("IQ_PBV", "Price/Book (x)"),
            ("IQ_PTBV", "Price/Tang Book (x)"),
            ("IQ_TEV_TOTAL_REV", "TEV/LTM Total Revenue (x)"),
            ("IQ_TEV_EBITDA", "TEV/LTM EBITDA (x)"),
            ("IQ_TOTAL_DEBT_EBITDA", "Total Debt/EBITDA (x)")
        ]

        for mnemonic, caption in desired_order:
            for identifier in identifiers:
                properties = {}
                payload = {
                    "identifier": identifier,
                    "mnemonic": mnemonic,
                    "function": function,
                    "properties": properties
                }
                mnemonics_payload.append(payload)

        return mnemonics_payload
