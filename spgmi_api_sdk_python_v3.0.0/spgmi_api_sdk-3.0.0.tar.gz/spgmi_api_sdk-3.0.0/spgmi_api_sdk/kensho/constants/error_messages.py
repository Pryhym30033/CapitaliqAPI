class ErrorMessages:
    _IDENTIFIERS_FORMAT_ERROR = "The 'identifiers' parameter must be a list with at least one identifier."
    _MNEMONICS_FORMAT_ERROR = "The 'mnemonics' parameter must be a list with at least one mnemonic."
    _IDENTIFIERS_SIZE = 10
    _MNEMONICS_SIZE = 10
    _IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR = f"The 'identifiers' list should not contain more than {_IDENTIFIERS_SIZE} items."
    _MNEMONICS_LIST_SIZE_EXCEEDED_ERROR = f"The 'mnemonics' list should not contain more than {_MNEMONICS_SIZE} items."
    _MNEMONIC_NOT_SUPPORTED_ERROR = "None of the 'mnemonics' provided are supported for the method"
    _DATA_UNAVAILABLE_ERROR = f"One or more company names provided are not supported. "

    @property
    def identifiers_format_error(self):
        return self._IDENTIFIERS_FORMAT_ERROR

    @property
    def mnemonics_format_error(self):
        return self._MNEMONICS_FORMAT_ERROR

    @property
    def identifiers_size(self):
        return self._IDENTIFIERS_SIZE

    @property
    def mnemonics_size(self):
        return self._MNEMONICS_SIZE

    @property
    def identifiers_list_size_exceeded_error(self):
        return self._IDENTIFIERS_LIST_SIZE_EXCEEDED_ERROR

    @property
    def data_unavailable_error(self):
        return self._DATA_UNAVAILABLE_ERROR


