import traceback
import pandas as pd
import logging
from spgmi_api_sdk.agencyratings.constants.error_messages import ErrorMessages
logger = logging.getLogger(__name__)
class DataFormat:

    def __init__(self):
        self.error_messages = ErrorMessages()


    def _format_response(self, response_json,identifier_mapping):
        response_json = response_json[0]
        #print(response_json)
        values = []
        if response_json:
            results = response_json.get("results", [])
            for result in results:
                identifier = "IQ" + result.get('identifierValue')

                if result.get('errorMessage') is None:
                    # Process S&P ratings
                    sp_ratings = result.get("s&pRatingsData", [])
                    if sp_ratings:
                        sp_data = sp_ratings[0].get("s&pData", [])
                        for sp_entry in sp_data:
                            values.append({
                                'Identifier': identifier,
                                'Agency': 'S&P',
                                'Rating Name': sp_entry.get('orgDebtType', 'Data Unavailable'),
                                'Rating Type': sp_entry.get('ratingType', 'Data Unavailable'),
                                'Rating Value': sp_entry.get('ratingValue', 'Data Unavailable'),
                                'Rating Date / Last Review Date*': f"{sp_entry.get('ratingDate', 'Data Unavailable')} / {sp_entry.get('lastReviewDate', 'Data Unavailable')}",
                                'Credit Watch / Outlook': sp_entry.get('creditWatchOutlookValue', 'Data Unavailable'),
                                'Credit Watch / Outlook Date': sp_entry.get('creditWatchOutlookDate',
                                                                            'Data Unavailable')
                            })

                    # Process Moody's ratings
                    moodys_ratings = result.get("moodysRatingsData", [])
                    if moodys_ratings:
                        moodys_data = moodys_ratings[0].get("moodysData", [])
                        for moodys_entry in moodys_data:
                            values.append({
                                'Identifier': identifier,
                                'Agency': "Moody's",
                                'Rating Name': moodys_entry.get('ratingTypeText', 'Data Unavailable'),
                                'Rating Type': moodys_entry.get('ratingClassText', 'Data Unavailable'),
                                'Rating Value': moodys_entry.get('ratingValue', 'Data Unavailable'),
                                'Rating Date / Last Review Date*': f"{moodys_entry.get('ratingDate', 'Data Unavailable')} / {moodys_entry.get('lastReviewDate', 'Data Unavailable')}",
                                'Credit Watch / Outlook': 'Data Unavailable',
                                'Credit Watch / Outlook Date': 'Data Unavailable'
                            })

                    # Process Fitch ratings
                    fitch_ratings = result.get("fitchRatingsData", [])
                    if fitch_ratings:
                        fitch_data = fitch_ratings[0].get("fitchData", [])
                        for fitch_entry in fitch_data:
                            values.append({
                                'Identifier': identifier,
                                'Agency': 'Fitch',
                                'Rating Name': fitch_entry.get('ratingTypeName', 'Data Unavailable'),
                                'Rating Type': 'Data Unavailable',
                                'Rating Value': fitch_entry.get('ratingValue', 'Data Unavailable'),
                                'Rating Date / Last Review Date*': f"{fitch_entry.get('ratingEffectiveDate', 'Data Unavailable')} / {fitch_entry.get('lastReviewDate', 'Data Unavailable')}",
                                'Credit Watch / Outlook': 'Data Unavailable',
                                'Credit Watch / Outlook Date': 'Data Unavailable'
                            })

                else:
                    values.append({
                        'Identifier': identifier,
                        'Agency': result.get('errorMessage'),
                        'Rating Name': result.get('errorMessage'),
                        'Rating Type': result.get('errorMessage'),
                        'Rating Value': result.get('errorMessage'),
                        'Rating Date / Last Review Date*': result.get('errorMessage'),
                        'Credit Watch / Outlook': result.get('errorMessage'),
                        'Credit Watch / Outlook Date': result.get('errorMessage')
                    })

        df = pd.DataFrame(values)

        # **Create a new DataFrame with mapped identifiers**
        new_rows = []

        for key, value in identifier_mapping.items():
            # Find rows where 'Identifier' matches the mapping value
            matching_rows = df[df['Identifier'] == value].copy()

            if not matching_rows.empty:
                matching_rows['Identifier'] = key  # Assign the mapped key as the new identifier
                new_rows.append(matching_rows)  # Collect the modified rows

        # Combine all new rows into a new DataFrame
        if new_rows:
            new_df = pd.concat(new_rows, ignore_index=True)
        else:
            new_df = pd.DataFrame(columns=df.columns)  # Return an empty DataFrame if no matches

        return new_df

    def _convert_to_dataframe(self, data,identifier_mapping,identifiers):
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', 1)

        try:
            expected_columns = [
                'Identifier', 'Agency', 'Rating Name', 'Rating Type', 'Rating Value',
                'Rating Date / Last Review Date*', 'Credit Watch / Outlook', 'Credit Watch / Outlook Date'
            ]

            if isinstance(data, list) and not data:
                df = pd.DataFrame(columns=expected_columns)
            else:
                df = pd.DataFrame(data)
            df.index = range(1, len(df) + 1)
            #df['Identifier'] = df['Identifier'].replace({v: k for k, v in identifier_mapping.items()})
            all_identifiers = set(identifier_mapping.keys())
            present_identifiers = set(df['Identifier'].unique())
            missing_identifiers = all_identifiers - present_identifiers
            for missing_identifier in missing_identifiers:
                error_message = identifier_mapping.get(missing_identifier, '').removeprefix("IQ")
                if error_message.isdigit():
                    error_message = "Data Unavailable"
                elif missing_identifier.upper().startswith("IQ"):
                    error_message = "Not Applicable"

                error_row = {col: error_message for col in expected_columns}
                error_row['Identifier'] = missing_identifier

                df = pd.concat([df, pd.DataFrame([error_row])], ignore_index=True)

            # Create new DataFrame in desired order
            ordered_rows = []
            for identifier in identifiers:
                rows = df[df['Identifier'] == identifier]  # Get all rows for this identifier
                ordered_rows.append(rows)

            # Concatenate all ordered rows into final DataFrame
            new_df = pd.concat(ordered_rows, ignore_index=True) if ordered_rows else pd.DataFrame(
                columns=expected_columns)

            new_df.index = range(1, len(new_df) + 1)  # Reset index to start from 1
            return new_df


            # response_color = 'lightyellow'
            # identifier_color = 'lightblue'
            #
            # # Ensure all columns are included for styling
            # columns_order = [col for col in df.columns]
            #
            # header_styles = [
            #     {'selector': 'th.col0',
            #      'props': [('background-color', identifier_color), ('text-align', 'center'),
            #                ('border', '1px solid black')]}
            # ]
            #
            # # Add styles for all columns
            # for i, col in enumerate(columns_order, start=1):  # Start at 1 for index alignment
            #     header_styles.append({'selector': f'th.col{i}',
            #                           'props': [('background-color', response_color), ('text-align', 'center'),
            #                                     ('border', '1px solid black')]})
            #
            # df_styled = df.style.set_table_styles(
            #     header_styles + [
            #         {'selector': 'td', 'props': [('text-align', 'center'), ('border', '1px solid black')]},
            #     ]
            # ).set_properties(**{'text-align': 'center'})




        except Exception as e:
            logger.error(f"DataFrame conversion error: {e}")
            #raise e
            traceback.print_exc()
            #return None
            raise e








