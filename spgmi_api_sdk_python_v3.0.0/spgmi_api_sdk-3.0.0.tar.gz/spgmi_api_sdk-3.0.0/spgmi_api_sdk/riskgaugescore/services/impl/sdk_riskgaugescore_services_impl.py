import traceback
from requests import HTTPError

import logging.config
from spgmi_api_sdk.dataservices.services.impl.sdk_data_services_impl import SDKDataServices
from spgmi_api_sdk.riskgaugescore.services.helper.riskgaugescore_request_utils import RiskGaugeScoreRequestUtils
from spgmi_api_sdk.riskgaugescore.services.sdk_riskgaugescore_interface import RiskGaugeScoreServicesInterface
from spgmi_api_sdk.riskgaugescore.services.helper.data_transform import DataFormat
from spgmi_api_sdk.riskgaugescore.services.helper.request_validator import RequestValidator
from spgmi_api_sdk.riskgaugescore.util.logging_utils import LoggingUtils

LoggingUtils.load_logging_config()
# Get the logger
logger = logging.getLogger(__name__)


class SDKRiskGaugeScoreServices(RiskGaugeScoreServicesInterface):

    def __init__(self):
        self.data_services = SDKDataServices()
        self.request_validator = RequestValidator()
        self.riskgauge_request_utils = RiskGaugeScoreRequestUtils()

    def get_risk_gauge_score(self, token, identifiers, scoring_date, proxy=None):
        error_messages = self.request_validator.validate_generic_request(identifiers,scoring_date)
        if error_messages:
            raise Exception(f"Error processing request: {', '.join(error_messages)}")
        try:
            identifier_mapping = self.data_services._convert_snl_ids_to_ciq(token, identifiers, proxy)
            identifiers_converted = list(identifier_mapping.values())

            payload = self.riskgauge_request_utils.generate_riskgaugescore_request_payload(identifiers_converted,scoring_date)
            response = self.data_services._invoke_data_service_with_payload(token, proxy, payload)
            df = DataFormat.getriskgaugescores_response_to_dataframe(response,identifier_mapping,scoring_date)
            return df

        except HTTPError as req_err:
            raise req_err
        except Exception as e:
            raise e
