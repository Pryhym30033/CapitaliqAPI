from spgmi_api_sdk.keydevs.constants.functions_constants import FunctionConstants
from spgmi_api_sdk.keydevs.constants.mnemonics_constants import MnemonicConstants


class DataConfig:


    def get_keydev_mnemonics(self):
        return MnemonicConstants._keydev_mnemonics

    def get_keydev_data_mnemonics_caption(self):
        return MnemonicConstants._keydev_mnemonics_captions

    def get_keydev_id_function(self):
        return FunctionConstants._keydev_id_function

    def get_keydev_id_mnemonics(self):
        return MnemonicConstants._keydev_id_mnemonics

    def get_keydev_function(self):
        return FunctionConstants._keydev_function





